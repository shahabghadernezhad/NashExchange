/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { MetalType, KycLevel, DocStatus, UserProfile, KycDocument, WalletBalances, Transaction, Order, PhysicalItem, TransactionType } from "./types";
import { INITIAL_RATES, INITIAL_TRANSACTIONS, INITIAL_ORDERS, INITIAL_PHYSICAL_ITEMS, INITIAL_NEWS } from "./data";

import Navbar from "./components/Navbar";
import ExchangeTerminal from "./components/ExchangeTerminal";
import WalletHub from "./components/WalletHub";
import KYCPortal from "./components/KYCPortal";
import PhysicalInventory from "./components/PhysicalInventory";
import AdminPanel from "./components/AdminPanel";
import BackendExporter from "./components/BackendExporter";

export default function App() {
  // Navigation State
  const [currentTab, setCurrentTab] = useState<string>("exchange");

  // Metal rates including slight random price fluctuations
  const [rates, setRates] = useState(INITIAL_RATES);

  // User details
  const [kycLevel, setKycLevel] = useState<KycLevel>(KycLevel.LEVEL_1); // Default Level 1 for demo
  const [phone, setPhone] = useState<string>("09123456789");
  const [email, setEmail] = useState<string>("shahabghadernezhad@gmail.com");
  const [fullName, setFullName] = useState<string>("شهاب قادرنژاد");
  const [nationalId, setNationalId] = useState<string>("2870385382");

  // Wallet balances
  const [balances, setBalances] = useState<WalletBalances>({
    rial: 1540000000, // 154 Million Toman (1,540,000,000 Rial)
    gold18k: 12.550,  // grams
    gold24k: 2.150,   // grams
    silver: 450.000,   // grams
    ingot: 1.000,     // Ingot (grams)
    usdt: 1250.00     // Tether
  });

  // Lists states
  const [transactions, setTransactions] = useState<Transaction[]>(INITIAL_TRANSACTIONS);
  const [orders, setOrders] = useState<Order[]>(INITIAL_ORDERS);
  const [physicalItems, setPhysicalItems] = useState<PhysicalItem[]>(INITIAL_PHYSICAL_ITEMS);
  const [documents, setDocuments] = useState<KycDocument[]>([
    {
      id: "DOC-991",
      userId: "USR-001",
      type: "NATIONAL_CARD",
      fileUrl: "https://images.unsplash.com/photo-1628157582853-a796fa650a6a?w=400",
      uploadDate: "2026-06-07T05:01:34Z",
      status: DocStatus.PENDING,
      ocrExtractedName: "شهاب قادرنژاد",
      ocrExtractedNationalId: "2870385382"
    }
  ]);

  const [feePercent, setFeePercent] = useState<number>(0.35); // base index

  // Rate refresh handler
  const handleRefreshRates = () => {
    setRates((prev) => {
      const g18kChange = (Math.random() - 0.5) * 150000;
      const g24kChange = (Math.random() - 0.5) * 200000;
      const silverChange = (Math.random() - 0.5) * 3500;
      const usdtChange = (Math.random() - 0.5) * 1500;
      const xauChange = (Math.random() - 0.5) * 15;

      return {
        ...prev,
        [MetalType.GOLD_18K]: Math.round(prev[MetalType.GOLD_18K] + g18kChange),
        [MetalType.GOLD_24K]: Math.round(prev[MetalType.GOLD_24K] + g24kChange),
        [MetalType.SILVER]: Math.round(prev[MetalType.SILVER] + silverChange),
        [MetalType.GOLD_INGOT]: Math.round(prev[MetalType.GOLD_INGOT] + g24kChange + 20000),
        USDT_RIAL: Math.round(prev.USDT_RIAL + usdtChange),
        XAU_USD: parseFloat((prev.XAU_USD + xauChange).toFixed(2))
      };
    });
  };

  // Simulate price changes on interval
  useEffect(() => {
    const timer = setInterval(() => {
      handleRefreshRates();
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  // Rial deposit handler (ZarinPal simulation)
  const handleDepositRial = (amount: number) => {
    setBalances((prev) => ({ ...prev, rial: prev.rial + amount }));
    
    const newTx: Transaction = {
      id: `TX-${Math.floor(10000 + Math.random() * 90000)}`,
      type: TransactionType.DEPOSIT_RIAL,
      amountRial: amount,
      timestamp: new Date().toISOString(),
      status: "SUCCESS",
      refId: `ZP-${Math.floor(100000 + Math.random() * 900000)}`
    };

    setTransactions((prev) => [newTx, ...prev]);
  };

  // Rial withdrawal handler (Shaba paya simulation)
  const handleWithdrawRial = (amount: number) => {
    setBalances((prev) => ({ ...prev, rial: prev.rial - amount }));
    
    const newTx: Transaction = {
      id: `TX-${Math.floor(10000 + Math.random() * 90000)}`,
      type: TransactionType.WITHDRAW_RIAL,
      amountRial: amount,
      timestamp: new Date().toISOString(),
      status: "SUCCESS"
    };

    setTransactions((prev) => [newTx, ...prev]);
  };

  // Swapping Tether direct to gold or rial
  const handleSwapUsdt = (usdtAmount: number, target: "rial" | MetalType) => {
    const rateRial = rates.USDT_RIAL;
    const valueRial = usdtAmount * rateRial;

    setBalances((prev) => {
      const next = { ...prev };
      next.usdt -= usdtAmount;
      if (target === "rial") {
        next.rial += valueRial;
      } else {
        const metalPrice = rates[target] || 1;
        const metalGrams = valueRial / metalPrice;
        if (target === MetalType.GOLD_18K) next.gold18k += metalGrams;
        if (target === MetalType.GOLD_24K) next.gold24k += metalGrams;
        if (target === MetalType.SILVER) next.silver += metalGrams;
        if (target === MetalType.GOLD_INGOT) next.ingot += metalGrams;
      }
      return next;
    });

    const newTx: Transaction = {
      id: `TX-${Math.floor(10000 + Math.random() * 90000)}`,
      type: TransactionType.SWAP_USDT,
      amountRial: valueRial,
      amountMetal: target !== "rial" ? usdtAmount * rateRial / rates[target] : undefined,
      metalType: target !== "rial" ? target : undefined,
      timestamp: new Date().toISOString(),
      status: "SUCCESS"
    };

    setTransactions((prev) => [newTx, ...prev]);
  };

  // Submit order from exchange book
  const handleCreateOrder = (orderData: Omit<Order, "id" | "timestamp" | "status">) => {
    const valueRial = orderData.price * orderData.quantity;
    const comm = valueRial * (feePercent / 100);

    const newOrd: Order = {
      ...orderData,
      id: `ORD-${Math.floor(10000 + Math.random() * 90000)}`,
      timestamp: new Date().toISOString(),
      status: "OPEN"
    };

    setOrders((prev) => [newOrd, ...prev]);

    // Handle instant checkout logic if order matches directly or market order is selected
    if (orderData.type === "MARKET" || Math.random() > 0.3) {
      setTimeout(() => {
        setOrders((prev) => prev.map((o) => o.id === newOrd.id ? { ...o, status: "FILLED" } : o).filter((o) => o.status === "OPEN"));
        
        // Execute wallet balances updates
        setBalances((prev) => {
          const next = { ...prev };
          const changeValue = valueRial / orderData.leverage;
          if (orderData.side === "BUY") {
            next.rial -= (changeValue + comm);
            if (orderData.metalType === MetalType.GOLD_18K) next.gold18k += orderData.quantity;
            if (orderData.metalType === MetalType.GOLD_24K) next.gold24k += orderData.quantity;
            if (orderData.metalType === MetalType.SILVER) next.silver += orderData.quantity;
            if (orderData.metalType === MetalType.GOLD_INGOT) next.ingot += orderData.quantity;
          } else {
            next.rial += (changeValue - comm);
            if (orderData.metalType === MetalType.GOLD_18K) next.gold18k -= orderData.quantity;
            if (orderData.metalType === MetalType.GOLD_24K) next.gold24k -= orderData.quantity;
            if (orderData.metalType === MetalType.SILVER) next.silver -= orderData.quantity;
            if (orderData.metalType === MetalType.GOLD_INGOT) next.ingot -= orderData.quantity;
          }
          return next;
        });

        // Log transaction history
        const newTx: Transaction = {
          id: `TX-${Math.floor(10000 + Math.random() * 90000)}`,
          type: orderData.side === "BUY" ? TransactionType.BUY_METAL : TransactionType.SELL_METAL,
          amountRial: valueRial,
          amountMetal: orderData.quantity,
          metalType: orderData.metalType,
          timestamp: new Date().toISOString(),
          status: "SUCCESS"
        };
        setTransactions((prev) => [newTx, ...prev]);
      }, 1000);
    }
  };

  // Cancel designated order
  const handleCancelOrder = (id: string) => {
    setOrders((prev) => prev.map((o) => o.id === id ? { ...o, status: "CANCELLED" } : o).filter((o) => o.status === "OPEN"));
  };

  // Physical gold warehouse dispatcher setup
  const handleDeliveryRequest = (metalType: MetalType, weight: number) => {
    // Reduct wallet
    setBalances((prev) => {
      const next = { ...prev };
      if (metalType === MetalType.GOLD_18K) next.gold18k -= weight;
      if (metalType === MetalType.GOLD_24K) next.gold24k -= weight;
      if (metalType === MetalType.SILVER) next.silver -= weight;
      if (metalType === MetalType.GOLD_INGOT) next.ingot -= weight;
      return next;
    });

    // Create delivery item
    const newItem: PhysicalItem = {
      id: `PHYS-${Math.floor(100 + Math.random() * 900)}`,
      metalType,
      weight,
      qrCode: `${metalType}-${weight}G-SEC-${Math.floor(100+Math.random()*900)}`,
      depotSection: `Safe Vault-GP-${Math.floor(10+Math.random()*90)}`,
      auditDate: new Date().toISOString(),
      status: "STORED"
    };

    setPhysicalItems((prev) => [newItem, ...prev]);
  };

  // Compliance admin actions
  const handleApproveDocument = (id: string) => {
    setDocuments((prev) => prev.map((d) => d.id === id ? { ...d, status: DocStatus.APPROVED } : d));
  };

  const handleRejectDocument = (id: string, reason: string) => {
    setDocuments((prev) => prev.map((d) => d.id === id ? { ...d, status: DocStatus.REJECTED, rejectionReason: reason } : d));
  };

  const addDocument = (doc: KycDocument) => {
    setDocuments((prev) => [doc, ...prev]);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col justify-between selection:bg-amber-500 selection:text-slate-950">
      
      {/* Dynamic Header */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        kycLevel={kycLevel}
        fullName={fullName}
        rialBalance={balances.rial}
        rates={rates}
        onRefresh={handleRefreshRates}
      />

      {/* Main Layout panels */}
      <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {currentTab === "exchange" && (
          <ExchangeTerminal
            kycLevel={kycLevel}
            rialBalance={balances.rial}
            rates={rates}
            orders={orders}
            onCreateOrder={handleCreateOrder}
            onCancelOrder={handleCancelOrder}
            balances={balances}
          />
        )}

        {currentTab === "wallet" && (
          <WalletHub
            balances={balances}
            rates={rates}
            transactions={transactions}
            onDepositRial={handleDepositRial}
            onWithdrawRial={handleWithdrawRial}
            onSwapUsdt={handleSwapUsdt}
          />
        )}

        {currentTab === "kyc" && (
          <KYCPortal
            kycLevel={kycLevel}
            setKycLevel={setKycLevel}
            phone={phone}
            setPhone={setPhone}
            email={email}
            setEmail={setEmail}
            fullName={fullName}
            setFullName={setFullName}
            nationalId={nationalId}
            setNationalId={setNationalId}
            documents={documents}
            addDocument={addDocument}
          />
        )}

        {currentTab === "physical" && (
          <PhysicalInventory
            rates={rates}
            physicalItems={physicalItems}
            walletBalances={balances}
            onDeliveryRequest={handleDeliveryRequest}
          />
        )}

        {currentTab === "admin" && (
          <AdminPanel
            documents={documents}
            onApproveDocument={handleApproveDocument}
            onRejectDocument={handleRejectDocument}
            kycLevel={kycLevel}
            setKycLevel={setKycLevel}
            feePercent={feePercent}
            setFeePercent={setFeePercent}
            walletBalances={balances}
          />
        )}

        {currentTab === "exporter" && (
          <BackendExporter />
        )}
      </main>

      {/* Global Footer */}
      <footer className="bg-slate-900 border-t border-slate-800 py-6 text-center text-xs text-slate-500 font-sans mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p>© {new Date().getFullYear()} پوتفرم مبادلات فلزات گرانبها زرین‌مهر. کلیه حقوق محفوظ است.</p>
          <div className="flex gap-4 text-slate-400">
            <span>درجه حفاظت: SSL + AES-256</span>
            <span>اتحادیه طلا تهران: فعال</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
