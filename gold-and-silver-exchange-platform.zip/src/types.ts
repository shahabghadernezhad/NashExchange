/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum MetalType {
  GOLD_18K = "GOLD_18K",
  GOLD_24K = "GOLD_24K",
  SILVER = "SILVER",
  GOLD_INGOT = "GOLD_INGOT"
}

export enum TransactionType {
  DEPOSIT_RIAL = "DEPOSIT_RIAL",
  WITHDRAW_RIAL = "WITHDRAW_RIAL",
  BUY_METAL = "BUY_METAL",
  SELL_METAL = "SELL_METAL",
  SWAP_USDT = "SWAP_USDT"
}

export enum OrderType {
  LIMIT = "LIMIT",
  MARKET = "MARKET",
  STOP_LOSS = "STOP_LOSS",
  TAKE_PROFIT = "TAKE_PROFIT"
}

export enum KycLevel {
  LEVEL_0 = "LEVEL_0", // Unverified
  LEVEL_1 = "LEVEL_1", // Daily up to 10g Gold
  LEVEL_2 = "LEVEL_2"  // Unlimited
}

export enum DocStatus {
  PENDING = "PENDING",
  APPROVED = "APPROVED",
  REJECTED = "REJECTED"
}

export interface UserProfile {
  id: string;
  phone: string;
  email: string;
  fullName: string;
  nationalId: string;
  kycLevel: KycLevel;
  twoFactorEnabled: boolean;
  registeredAt: string;
}

export interface KycDocument {
  id: string;
  userId: string;
  type: "NATIONAL_CARD" | "BIRTH_CERTIFICATE";
  fileUrl: string;
  uploadDate: string;
  status: DocStatus;
  ocrExtractedName?: string;
  ocrExtractedNationalId?: string;
  rejectionReason?: string;
}

export interface WalletBalances {
  rial: number;
  gold18k: number; // in grams
  gold24k: number; // in grams
  silver: number;  // in grams
  ingot: number;   // in grams
  usdt: number;    // Tether
}

export interface Transaction {
  id: string;
  type: TransactionType;
  amountRial: number;
  amountMetal?: number;
  metalType?: MetalType;
  senderAddress?: string;
  refId?: string;
  timestamp: string;
  status: "SUCCESS" | "PENDING" | "FAILED";
}

export interface OrderBookItem {
  price: number;
  quantity: number;
  total: number;
}

export interface Order {
  id: string;
  metalType: MetalType;
  type: OrderType;
  side: "BUY" | "SELL";
  price: number;
  quantity: number; // in grams
  leverage: number; // 1 to 100
  timestamp: string;
  status: "OPEN" | "FILLED" | "CANCELLED";
}

export interface PhysicalItem {
  id: string;
  metalType: MetalType;
  weight: number; // in grams
  qrCode: string;
  depotSection: string;
  auditDate: string;
  status: "STORED" | "SHIPPED" | "DELIVERED";
}

export interface PriceAlert {
  id: string;
  metalType: MetalType;
  targetPrice: number;
  condition: "ABOVE" | "BELOW";
  channel: "SMS" | "EMAIL" | "PUSH";
  isActive: boolean;
}

export interface NewsItem {
  id: string;
  title: string;
  summary: string;
  source: string;
  sentiment: "BULLISH" | "BEARISH" | "NEUTRAL";
  timestamp: string;
  category: "WORLD" | "IRAN" | "ANALYSIS";
}
