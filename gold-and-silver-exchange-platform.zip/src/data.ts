/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { MetalType, TransactionType, OrderType, KycLevel, DocStatus, Transaction, OrderBookItem, Order, PhysicalItem, NewsItem } from "./types";

export const INITIAL_RATES = {
  [MetalType.GOLD_18K]: 45500000, // Rial per gram (approx 4.5M Toman)
  [MetalType.GOLD_24K]: 60660000, // Rial per gram
  [MetalType.SILVER]: 580000,    // Rial per gram
  [MetalType.GOLD_INGOT]: 61000000, // Rial per gram (24k refined ingot)
  USDT_RIAL: 690000, // Rial per Tether
  XAU_USD: 2420.50, // USD per ounce
};

// Initial market bids & asks for order book
export const INITIAL_BIDS: OrderBookItem[] = [
  { price: 45480000, quantity: 12.5, total: 568500000 },
  { price: 45450000, quantity: 8.2, total: 372690000 },
  { price: 45400000, quantity: 24.0, total: 1089600000 },
  { price: 45350000, quantity: 45.1, total: 2045285000 },
  { price: 45300000, quantity: 150.0, total: 6795000000 },
];

export const INITIAL_ASKS: OrderBookItem[] = [
  { price: 45520000, quantity: 5.4, total: 245808000 },
  { price: 45550000, quantity: 18.1, total: 824455000 },
  { price: 45600000, quantity: 33.0, total: 1504800000 },
  { price: 45650000, quantity: 60.5, total: 2761825000 },
  { price: 45700000, quantity: 120.0, total: 5484000000 },
];

export const INITIAL_TRANSACTIONS: Transaction[] = [
  {
    id: "TX-10928",
    type: TransactionType.DEPOSIT_RIAL,
    amountRial: 500000000, // 50 Million Toman
    timestamp: "2026-06-07T05:22:15Z",
    status: "SUCCESS",
    refId: "ZP-881920"
  },
  {
    id: "TX-10927",
    type: TransactionType.BUY_METAL,
    amountRial: 227500000,
    amountMetal: 5,
    metalType: MetalType.GOLD_18K,
    timestamp: "2026-06-07T04:10:00Z",
    status: "SUCCESS",
    refId: "EX-98218"
  },
  {
    id: "TX-10926",
    type: TransactionType.SWAP_USDT,
    amountRial: 345000000, // Swap 500 USDT to gold equivalent
    amountMetal: 0.5,
    metalType: MetalType.GOLD_INGOT,
    timestamp: "2026-06-06T18:45:00Z",
    status: "SUCCESS",
    refId: "SW-441021"
  },
  {
    id: "TX-10925",
    type: TransactionType.WITHDRAW_RIAL,
    amountRial: 120000000,
    timestamp: "2026-06-05T12:05:00Z",
    status: "SUCCESS",
    refId: "SH-55109"
  }
];

export const INITIAL_ORDERS: Order[] = [
  {
    id: "ORD-9912",
    metalType: MetalType.GOLD_18K,
    type: OrderType.LIMIT,
    side: "BUY",
    price: 45300000,
    quantity: 2.5,
    leverage: 1,
    timestamp: "2026-06-07T05:00:00Z",
    status: "OPEN"
  },
  {
    id: "ORD-9911",
    metalType: MetalType.GOLD_INGOT,
    type: OrderType.LIMIT,
    side: "SELL",
    price: 61500000,
    quantity: 10,
    leverage: 5,
    timestamp: "2026-06-06T14:20:00Z",
    status: "OPEN"
  }
];

export const INITIAL_PHYSICAL_ITEMS: PhysicalItem[] = [
  {
    id: "PHYS-001",
    metalType: MetalType.GOLD_INGOT,
    weight: 100,
    qrCode: "GOLD-INGOT-100G-SEC-A4",
    depotSection: "Safe Vault-A4",
    auditDate: "2026-06-01T09:00:00Z",
    status: "STORED"
  },
  {
    id: "PHYS-002",
    metalType: MetalType.GOLD_24K,
    weight: 50,
    qrCode: "GOLD-24K-50G-SEC-B1",
    depotSection: "Safe Vault-B1",
    auditDate: "2026-06-04T11:30:00Z",
    status: "STORED"
  },
  {
    id: "PHYS-003",
    metalType: MetalType.SILVER,
    weight: 500,
    qrCode: "SILVER-500G-SEC-C2",
    depotSection: "Silver Cabin-C2",
    auditDate: "2026-06-03T15:00:00Z",
    status: "STORED"
  }
];

export const INITIAL_NEWS: NewsItem[] = [
  {
    id: "NEWS-1",
    title: "نوسانات شدید طلا در بازارهای جهانی همزمان با گزارشهای تورم آمریکا",
    summary: "قیمت اونس جهانی طلا به مرز ۲۴۲۰ دلار رسید. فعالان بازار معتقدند کاهش سود بانکی توسط فدرال رزرو می‌تواند طلا را به رکوردهای جدیدی سوق دهد.",
    source: "بلومبرگ فارسی",
    sentiment: "BULLISH",
    timestamp: "2026-06-07T05:30:00Z",
    category: "WORLD"
  },
  {
    id: "NEWS-2",
    title: "اطلاعیه جدید اتحادیه طلا و جواهر تهران درباره مالیات بر ارزش افزوده",
    summary: "رئیس اتحادیه طلا اعلام کرد خرید طلای آب شده کماکان معاف از ارزش افزوده است و تنها اجرت ساخت و سود گالری مشمول ۹ درصد مالیات ارزش افزوده می‌شود.",
    source: "اتحادیه طلا تهران",
    sentiment: "NEUTRAL",
    timestamp: "2026-06-06T19:15:00Z",
    category: "IRAN"
  },
  {
    id: "NEWS-3",
    title: "تحلیل تکنیکال نقره: عبور پرقدرت از مقاومت تاریخی پس از تقاضای صنعتی چین",
    summary: "نمودار چهارساعته نقره نشان‌دهنده یک واگرایی مثبت در RSI و کراس طلایی در مکدی (MACD) است که نشان از موج صعودی جدید دارد.",
    source: "تریدینگ ویو فارسی",
    sentiment: "BULLISH",
    timestamp: "2026-06-06T12:00:00Z",
    category: "ANALYSIS"
  }
];

// Historical candles for candlestick chart
export const GENERATE_CANDLES = (startPrice: number, points = 30) => {
  let currentPrice = startPrice;
  const result = [];
  
  for (let i = points; i >= 0; i--) {
    const change = (Math.random() - 0.48) * (currentPrice * 0.005);
    const open = currentPrice;
    const close = currentPrice + change;
    const high = Math.max(open, close) + Math.random() * (currentPrice * 0.002);
    const low = Math.min(open, close) - Math.random() * (currentPrice * 0.002);
    
    // Estimate some simple manual indicators for the graph
    // (e.g., mock RSI and MACD value based on variations)
    const rsi = Math.floor(45 + (change / (currentPrice * 0.005)) * 15 + Math.random() * 8);
    
    // Create UTC date subtracts
    const d = new Date();
    d.setMinutes(d.getMinutes() - i * 15);
    
    result.push({
      time: d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      open: Math.round(open),
      high: Math.round(high),
      low: Math.round(low),
      close: Math.round(close),
      rsi: Math.max(10, Math.min(90, rsi)),
      macd: (change / 100000) * 1.5,
      volume: Math.round(5 + Math.random() * 45)
    });
    
    currentPrice = close;
  }
  return result;
};
