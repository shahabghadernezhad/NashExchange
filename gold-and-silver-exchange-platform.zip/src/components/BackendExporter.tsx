/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { FolderTree, Settings, FileCode, Server, Play, HelpCircle, FileText, Check, Copy } from "lucide-react";

export default function BackendExporter() {
  const [activeTab, setActiveTab] = useState<"architecture" | "django_settings" | "django_models" | "consumers" | "docker" | "readme">("architecture");
  const [copiedState, setCopiedState] = useState<string | null>(null);

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedState(label);
    setTimeout(() => {
      setCopiedState(null);
    }, 2000);
  };

  const codeSnippets = {
    architecture: `ZarrinGold/
├── backend/                  # Django 5 Full Backend Stack
│   ├── manage.py
│   ├── requirements.txt
│   ├── Dockerfile
│   ├── zarrin_gold/          # Project Settings Core
│   │   ├── __init__.py
│   │   ├── settings.py       # Production-grade Security, Database, OAuth & Celery Configuration
│   │   ├── urls.py
│   │   ├── asgi.py           # ASGI Setup for WebSockets Channels
│   │   └── wsgi.py
│   ├── exchange/             # Main Trading app
│   │   ├── __init__.py
│   │   ├── models.py         # DB Schemas: User, Wallet, Order, Transaction, KycDocument, GoldItem, News
│   │   ├── views.py          # REST APIs for order submission, KYC updates, wallet operations
│   │   ├── serializers.py
│   │   ├── consumers.py      # Django Channels Order Book WebSocket Consumer
│   │   ├── routing.py
│   │   ├── tasks.py          # Celery background tasks (Postgres auto backup, Live Union Pricing)
│   │   └── urls.py
│   └── celery_app.py
├── frontend/                 # Next.js 14 Web Application
│   ├── package.json
│   ├── tsconfig.json
│   ├── Dockerfile
│   ├── tailwind.config.ts
│   ├── src/
│   │   ├── app/
│   │   │   ├── layout.tsx
│   │   │   ├── page.tsx      # Exchange Terminal & Wallets
│   │   │   └── kyc/
│   └── public/
├── docker-compose.yml        # Orchestrator (Postgres 16, Redis 7, Elasticsearch 8, Django, NEXT, Celery, RabitMQ)
└── .env.example              # Environments list`,

    django_settings: `"""
Production Settings configuration for ZarrinGold platform.
Built with Django 5 + PostgreSQL 16 + Celery + Elasticsearch
"""
import os
from pathlib import Path
from datetime import timedelta

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = os.environ.get('DJANGO_SECRET_KEY', 'django-insecure-aes-key-production-change-this!')

DEBUG = os.environ.get('DEBUG', 'False') == 'True'

ALLOWED_HOSTS = os.environ.get('ALLOWED_HOSTS', '*').split(',')

# Production Safety HTTP Headers
SECURE_SSL_REDIRECT = os.environ.get('SECURE_SSL_REDIRECT', 'True') == 'True'
SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True
SECURE_BROWSER_XSS_FILTER = True
SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_HSTS_SECONDS = 31536000
SECURE_HSTS_INCLUDE_SUBDOMAINS = True
SECURE_HSTS_PRELOAD = True

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    
    # Third party packages
    'rest_framework',
    'rest_framework_simplejwt',
    'channels',
    'corsheaders',
    'django_celery_beat',
    
    # Project apps
    'exchange',
]

MIDDLEWARE = [
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'zarrin_gold.urls'
WSGI_APPLICATION = 'zarrin_gold.wsgi.application'
ASGI_APPLICATION = 'zarrin_gold.asgi.application'

# PostgreSQL 16 Database config
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': os.environ.get('POSTGRES_DB', 'zarrin_db'),
        'USER': os.environ.get('POSTGRES_USER', 'zarrin_admin'),
        'PASSWORD': os.environ.get('POSTGRES_PASSWORD', 'SuperSecurePass16!'),
        'HOST': os.environ.get('POSTGRES_HOST', 'postgres-db'),
        'PORT': os.environ.get('POSTGRES_PORT', '5432'),
    }
}

# Redis & Channels routing configurations
CHANNEL_LAYERS = {
    'default': {
        'BACKEND': 'channels_redis.core.RedisChannelLayer',
        'CONFIG': {
            "hosts": [os.environ.get('REDIS_URL', 'redis://redis-server:6379/1')],
        },
    },
}

# REST Framework SimpleJWT Security
REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'rest_framework_simplejwt.authentication.JWTAuthentication',
    ),
    'DEFAULT_PERMISSION_CLASSES': (
        'rest_framework.permissions.IsAuthenticated',
    )
}

SIMPLE_JWT = {
    'ACCESS_TOKEN_LIFETIME': timedelta(minutes=60),
    'REFRESH_TOKEN_LIFETIME': timedelta(days=7),
    'ROTATE_REFRESH_TOKENS': True,
    'ALGORITHM': 'HS256',
    'SIGNING_KEY': SECRET_KEY,
}

# Celery Configurations
CELERY_BROKER_URL = os.environ.get('CELERY_BROKER', 'amqp://guest:guest@rabbitmq-broker:5672/')
CELERY_RESULT_BACKEND = os.environ.get('CELERY_BACKEND', 'redis://redis-server:6379/2')
CELERY_ACCEPT_CONTENT = ['json']
CELERY_TASK_SERIALIZER = 'json'

# Celery Crontab tasks schedulers
CELERY_BEAT_SCHEDULE = {
    'database-backup-every-4-hours': {
        'task': 'exchange.tasks.backup_database',
        'schedule': timedelta(hours=4),
    },
    'sync-gold-union-prices-every-2-minutes': {
        'task': 'exchange.tasks.sync_union_prices',
        'schedule': timedelta(minutes=2),
    },
}`,

    django_models: `from django.db import models
from django.contrib.auth.models import AbstractUser
from decimal import Decimal
import uuid

class User(AbstractUser):
    """
    Extends standard auth user for gold trading accounts
    """
    KYC_LEVELS = (
        (0, 'Level 0 - Unverified'),
        (1, 'Level 1 - Up to 10g Gold daily'),
        (2, 'Level 2 - Unlimited trading'),
    )
    phone_number = models.CharField(max_length=15, unique=True, db_index=True)
    kyc_level = models.IntegerField(choices=KYC_LEVELS, default=0)
    national_id = models.CharField(max_length=10, unique=True, null=True, blank=True)
    is_two_factor_enabled = models.BooleanField(default=False)
    aes_encrypted_melli_hash = models.TextField(null=True, blank=True) # AES-256 secure hash to prevent duplicate registers

    class Meta:
        db_table = 'zarrin_user'


class Wallet(models.Model):
    """
    Multicurrency smart wallet of golds, silvers, and rial
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='wallet')
    rial_balance = models.DecimalField(max_digits=18, decimal_places=0, default=0) # Rial currency (BigDecimal equivalent)
    gold18k_balance = models.DecimalField(max_digits=10, decimal_places=4, default=0) # grams
    gold24k_balance = models.DecimalField(max_digits=10, decimal_places=4, default=0) # grams
    silver_balance = models.DecimalField(max_digits=10, decimal_places=4, default=0) # grams
    ingot_balance = models.DecimalField(max_digits=10, decimal_places=4, default=0) # grams
    tether_usdt_balance = models.DecimalField(max_digits=12, decimal_places=2, default=0) # USDT

    class Meta:
        db_table = 'zarrin_wallet'


class Order(models.Model):
    """
    Trading orders logs for matching (Limit, Market, Stop-Loss / Take-Profit)
    """
    METALS = (
        ('GOLD_18K', 'Gold 18 Karat'),
        ('GOLD_24K', 'Gold 24 Karat'),
        ('SILVER', 'Silver industrial'),
        ('GOLD_INGOT', 'Gold Pure Ingot'),
    )
    ORDER_TYPES = (
        ('LIMIT', 'Limit order'),
        ('MARKET', 'Market order'),
        ('STOP_LOSS', 'Stop-loss conditional'),
    )
    SIDES = (
        ('BUY', 'Buy Order'),
        ('SELL', 'Sell Order'),
    )
    STATUSES = (
        ('OPEN', 'Open in matchbook'),
        ('FILLED', 'Filled completely'),
        ('CANCELLED', 'Cancelled by user'),
    )
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='orders')
    metal_type = models.CharField(max_length=15, choices=METALS)
    order_type = models.CharField(max_length=15, choices=ORDER_TYPES)
    side = models.CharField(max_length=10, choices=SIDES)
    price = models.DecimalField(max_digits=15, decimal_places=0) # Rial per gram
    quantity = models.DecimalField(max_digits=10, decimal_places=4) # In grams
    leverage = models.IntegerField(default=1) # 1x up to 100x
    status = models.CharField(max_length=15, choices=STATUSES, default='OPEN')
    timestamp = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        db_table = 'zarrin_order'


class Transaction(models.Model):
    """
    Auditable transaction histories with double-entry integrity
    """
    TX_TYPES = (
        ('DEPOSIT_RIAL', 'Deposit cash Rials'),
        ('WITHDRAW_RIAL', 'Withdraw Rials via Shaba'),
        ('BUY_METAL', 'Purchased Gold/Silver'),
        ('SELL_METAL', 'Sold Gold/Silver'),
        ('SWAP_USDT', 'Swapped Tether directly'),
    )
    id = models.CharField(max_length=32, primary_key=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='transactions')
    tx_type = models.CharField(max_length=20, choices=TX_TYPES)
    amount_rial = models.DecimalField(max_digits=18, decimal_places=0)
    amount_metal = models.DecimalField(max_digits=10, decimal_places=4, null=True, blank=True)
    metal_classification = models.CharField(max_length=15, null=True, blank=True)
    zarinpal_ref_id = models.CharField(max_length=40, null=True, blank=True)
    status = models.CharField(max_length=12, default='SUCCESS')
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'zarrin_transaction'


class KycDocument(models.Model):
    """
    KYC identity papers including custom OCR recognition results
    """
    DOC_STATUSES = (
        ('PENDING', 'Pending human review'),
        ('APPROVED', 'Approved by Compliance'),
        ('REJECTED', 'Rejected'),
    )
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='kyc_documents')
    doc_type = models.CharField(max_length=20, default='NATIONAL_CARD')
    image_file = models.ImageField(upload_to='compliance_docs/')
    ocr_extracted_national_id = models.CharField(max_length=10, null=True, blank=True)
    ocr_extracted_fullname = models.CharField(max_length=150, null=True, blank=True)
    status = models.CharField(max_length=12, choices=DOC_STATUSES, default='PENDING')
    review_comments = models.TextField(null=True, blank=True)
    reviewed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = 'zarrin_kyc_document'`,

    consumers: `import json
from channels.generic.websocket import AsyncWebsocketConsumer

class OrderBookConsumer(AsyncWebsocketConsumer):
    """
    WS Consumer providing sub-second Order Book level 2 data to active traders
    """
    async def connect(self):
        self.metal_group_name = "orderbook_live"

        # Join orderbook feed channels group
        await self.channel_layer.group_add(
            self.metal_group_name,
            self.channel_name
        )
        await self.accept()

    async def disconnect(self, close_code):
        # Leave channels group
        await self.channel_layer.group_discard(
            self.metal_group_name,
            self.channel_name
        )

    async def receive(self, text_data):
        # Handle custom incoming orders requests if any
        data_json = json.loads(text_data)
        action = data_json.get("action")
        
        if action == "subscribe_depth":
            metal_type = data_json.get("metal_type")
            # Push initial depth
            await self.send(text_data=json.dumps({
                "event": "depth_initial",
                "metal_type": metal_type,
                "message": f"Successfully subscribed to WebSocket orderbook channel for {metal_type}."
            }))

    async def send_orderbook_update(self, event):
        """
        Triggered when database/matching core fires order matching updates
        """
        payload = event["payload"]
        await self.send(text_data=json.dumps({
            "event": "depth_update",
            "data": payload
        }))`,

    docker: `version: "3.9"

services:
  postgres-db:
    image: postgres:16-alpine
    container_name: postgres16_zarrin
    environment:
      POSTGRES_DB: zarrin_db
      POSTGRES_USER: zarrin_admin
      POSTGRES_PASSWORD: SuperSecurePass16!
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data
    networks:
      - exchange-network

  redis-server:
    image: redis:7-alpine
    container_name: redis7_zarrin
    ports:
      - "6379:6379"
    networks:
      - exchange-network

  rabbitmq-broker:
    image: rabbitmq:3-management-alpine
    container_name: rabbitmq3_zarrin
    ports:
      - "5672:5672"
      - "15672:15672" # Management Plugin UI Web
    networks:
      - exchange-network

  django-backend:
    build:
      context: ./backend
      dockerfile: Dockerfile
    container_name: django_app
    command: python manage.py runserver 0.0.0.0:8000
    volumes:
      - ./backend:/app
    ports:
      - "8000:8000"
    environment:
      - DEBUG=True
      - DJANGO_SECRET_KEY=zarrin-exclusive-production-key-2026
      - POSTGRES_DB=zarrin_db
      - POSTGRES_USER=zarrin_admin
      - POSTGRES_PASSWORD=SuperSecurePass16!
      - POSTGRES_HOST=postgres-db
      - REDIS_URL=redis://redis-server:6379/1
      - CELERY_BROKER=amqp://guest:guest@rabbitmq-broker:5672/
    depends_on:
      - postgres-db
      - redis-server
      - rabbitmq-broker
    networks:
      - exchange-network

  celery-worker:
    build:
      context: ./backend
    container_name: celery_worker_app
    command: celery -A zarrin_gold worker --beat --scheduler django_celery_beat.schedulers:DatabaseScheduler -l info
    volumes:
      - ./backend:/app
    environment:
      - POSTGRES_DB=zarrin_db
      - POSTGRES_USER=zarrin_admin
      - POSTGRES_PASSWORD=SuperSecurePass16!
      - POSTGRES_HOST=postgres-db
      - REDIS_URL=redis://redis-server:6379/1
      - CELERY_BROKER=amqp://guest:guest@rabbitmq-broker:5672/
    depends_on:
      - postgres-db
      - redis-server
      - django-backend
    networks:
      - exchange-network

  nextjs-frontend:
    build:
      context: ./frontend
    container_name: nextjs_app
    ports:
      - "3000:3000"
    volumes:
      - ./frontend:/app
    environment:
      - NEXT_PUBLIC_API_URL=http://localhost:8000
      - NEXT_PUBLIC_WS_URL=ws://localhost:8000
    depends_on:
      - django-backend
    networks:
      - exchange-network

volumes:
  postgres_data:

networks:
  exchange-network:
    driver: bridge`,

    readme: `# 🪙 پلتفرم معاملاتی طلا و نقره زرین‌مهر (ZarrinGold)

یک سامانه صرافی و معاملاتی فیزیکی و دیجیتال برای انواع فلزات گرانبها با معماری تمیز (Clean Architecture) بر مبنای جنگو ۵ و ری‌اکت/Next.js به همراه سیستم ممیزی مدارک بیومتریک و اتصال زرین‌پال.

---

## 🚀 راه اندازی سریع با داکر (Quickstart Docker)

برای استقرار و اجرای کامل کل سرویس‌ها (PostgreSQL 16, Redis 7, RabbitMQ, backend Django, Celery, Next.js frontend) تنها کافیست دستور زیر را وارد نمایید:

\`\`\`bash
# کلون کرده و بالا اوردن کل پشته با داکر کامپوز
docker-compose up -d --build
\`\`\`

این دستور معماری زیر را به راه می‌اندازد:
1. **داشبورد ری‌اکت**: پورت 3000
2. **سرویس‌های بک‌اند Django / REST APIs**: پورت 8000
3. **تسک رانرهای هوشمند Celery**: دوره‌ای هر ۴ ساعت برای بكاپ‌گیری و همسان‌سازی قیمت از اتحادیه طلا
4. **دژ بانک اطلاعاتی PostgreSQL**: پورت 5432
5. **موتور مبادلاتی پیام RabbitMQ**: پورت 5672

---

## 🛠️ متغیرهای محیطی مورد نیاز (.env.example)

پروژه را از روی فایل \`.env.example\` کپی کرده و مقداردهی نمایید:

\`\`\`env
# Django security properties
DJANGO_SECRET_KEY="production-secret-must-be-highly-complex"
DEBUG=False
ALLOWED_HOSTS="your-domain.com,localhost"

# Relational database details
POSTGRES_DB="zarrin_db"
POSTGRES_USER="zarrin_admin"
POSTGRES_PASSWORD="SuperSecureStrongPassword16!"
POSTGRES_HOST="postgres-db"
POSTGRES_PORT=5432

# Redis & Channels Layer
REDIS_URL="redis://redis-server:6379/1"

# RabbitMQ & Celery
CELERY_BROKER="amqp://guest:guest@rabbitmq-broker:5672/"

# Merchant gateways
ZARINPAL_MERCHANT_ID="your-merchant-id-zarinpal"
GOLD_UNION_API_KEY="your-gold-union-secret-key"
\`\`\`

---

## 🔑 قابلیت‌های برتر امنیتی پیاده‌سازی شده
- **رمزنگاری تراکنش‌ها**: استفاده از الگوریتم دوطرفه AES-256 برای داده‌های کاربران (مانند شماره شبا و کد ملی منحصر به فرد).
- **کیف پول امن**: عدم امکان ثبت تراکنش مخدوش به دلیل بهره‌گیری از تکنیک‌های تراکنش اتمی پایگاه داده (\`transaction.atomic\`).
- **پشتیبان‌گیری منظم**: راه‌اندازی تسک‌های زمانبندی با کرون‌تاب Celery Beat جهت فشرده‌سازی خودکار دیتابیس و انتقال امن به باکت‌های S3.`
  };

  const tabs = [
    { id: "architecture", name: "ساختار کل درخت پروژه", icon: FolderTree },
    { id: "django_settings", name: "فایل تنظیمات (settings.py)", icon: Settings },
    { id: "django_models", name: "مدل‌های جنگو (models.py)", icon: FileCode },
    { id: "consumers", name: "کانال وب‌ساکت (consumers.py)", icon: Server },
    { id: "docker", name: "داکر کامپوز (docker-compose.yml)", icon: Play },
    { id: "readme", name: "فایل راهنما (README.md فارسی)", icon: FileText }
  ];

  const getActiveContent = () => {
    return codeSnippets[activeTab];
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 text-right font-sans shadow-xl">
      <div className="border-b border-slate-800 pb-4 mb-6">
        <h2 className="text-xl font-bold text-white flex items-center justify-end gap-2">
          کدهای خروجی آماده استقرار و پیاده‌سازی (Django Stack)
          <FileCode className="h-6 w-6 text-amber-500 shrink-0" />
        </h2>
        <p className="text-xs text-slate-400 mt-1">کلیه کدهای مورد نیاز، داکر فایل، فایل‌های جنگو و داکر کامپوز را برای استقرار آسان در سرور دانلود کنید یا رونوشت بردارید.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
        
        {/* Left hand tabs select */}
        <div className="lg:col-span-1 space-y-2">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`w-full flex items-center justify-between p-3.5 rounded-xl text-xs font-semibold border transition-all ${
                  isActive
                    ? "bg-amber-500/10 border-amber-500 text-amber-500 shadow-lg shadow-amber-500/5"
                    : "bg-slate-950 border-slate-800 text-slate-400 hover:text-white"
                }`}
              >
                <Icon className="h-4 w-4 shrink-0" />
                <span>{tab.name}</span>
              </button>
            );
          })}
        </div>

        {/* Right hand code panel */}
        <div className="lg:col-span-3 space-y-4">
          <div className="bg-slate-950 rounded-2xl border border-slate-850 overflow-hidden shadow">
            
            {/* Action headers */}
            <div className="bg-slate-900 py-3.5 px-5 flex justify-between items-center border-b border-slate-800/80">
              <button
                onClick={() => handleCopy(getActiveContent(), activeTab)}
                className="text-xs bg-slate-800 hover:bg-slate-750 text-slate-300 font-bold py-1.5 px-3 rounded-lg flex items-center gap-1.5 transition-colors"
                id={`btn-copy-${activeTab}`}
              >
                {copiedState === activeTab ? (
                  <>
                    <Check className="h-3.5 w-3.5 text-emerald-400" />
                    <span className="text-emerald-400">کپی شد!</span>
                  </>
                ) : (
                  <>
                    <Copy className="h-3.5 w-3.5 text-amber-500" />
                    <span>کپی کد کامل</span>
                  </>
                )}
              </button>

              <span className="text-[11px] font-mono text-slate-500">
                {activeTab === "architecture" && "file_tree.txt"}
                {activeTab === "django_settings" && "settings.py"}
                {activeTab === "django_models" && "models.py"}
                {activeTab === "consumers" && "consumers.py"}
                {activeTab === "docker" && "docker-compose.yml"}
                {activeTab === "readme" && "README.md"}
              </span>
            </div>

            {/* Code Body */}
            <pre className="text-left font-mono text-xs text-slate-300 p-5 overflow-auto h-[450px] no-scrollbar leading-relaxed">
              <code>{getActiveContent()}</code>
            </pre>

          </div>
        </div>

      </div>
    </div>
  );
}
