/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Users, Coins, Percent, ShieldCheck, Database, Trash2, Eye, Award, CheckCircle2, XCircle } from "lucide-react";
import { KycLevel, DocStatus, KycDocument } from "../types";

interface AdminPanelProps {
  documents: KycDocument[];
  onApproveDocument: (id: string) => void;
  onRejectDocument: (id: string, reason: string) => void;
  kycLevel: KycLevel;
  setKycLevel: (level: KycLevel) => void;
  feePercent: number;
  setFeePercent: (fee: number) => void;
  walletBalances: any;
}

export default function AdminPanel({
  documents,
  onApproveDocument,
  onRejectDocument,
  kycLevel,
  setKycLevel,
  feePercent,
  setFeePercent,
  walletBalances
}: AdminPanelProps) {
  const [rejectReason, setRejectReason] = useState<string>("");
  const [activeRejectId, setActiveRejectId] = useState<string | null>(null);

  // Simulated metrics
  const [metrics, setMetrics] = useState({
    activeUsers: 1422,
    totalTradingVolume: 125440000000, // Rial (12.5 Billion Toman)
    commissionEarned: 432240900,      // Rial commission earned
    dbSizeMb: 12.4,
    lastBackup: "2026-06-07T04:00:00Z"
  });

  const [backupLogs, setBackupLogs] = useState<string[]>([
    "[2026-06-07 04:00:00] Celery Job: db_backup_task triggered successfully.",
    "[2026-06-07 04:00:05] pg_dump completed. Compressed output: backup_20260607_0400.sql.gz (1.2 MB)",
    "[2026-06-07 04:00:08] Backup synchronized with Amazon S3 bucket 'zarrin-primary-backups'. Status: SECURED.",
    "[2026-06-07 00:00:00] Celery Job: db_backup_task triggered successfully.",
    "[2026-06-07 00:00:04] pg_dump completed. Compressed output: backup_20260607_0000.sql.gz (1.1 MB)"
  ]);

  const [isBackingUp, setIsBackingUp] = useState(false);

  const handleManualBackup = () => {
    setIsBackingUp(true);
    setTimeout(() => {
      const logTime = new Date().toISOString();
      const filename = `backup_${logTime.replace(/[-:T]/g, "").slice(0, 12)}.sql.gz`;
      setBackupLogs((prev) => [
        `[${new Date().toLocaleString()}] دستیابی به پورت دیتابیس PostgreSQL فعال گردید.`,
        `[${new Date().toLocaleString()}] فایل پشتیبان فشرده با موفقیت ذخیره شد: ${filename} (1.3 MB)`,
        ...prev
      ]);
      setMetrics((m) => ({ ...m, lastBackup: logTime, dbSizeMb: m.dbSizeMb + 0.1 }));
      setIsBackingUp(false);
      alert("یک نسخه پشتیبان کامل از دیتابیس PostgreSQL و کش Redis با موفقیت تهیه و رمزگذاری گردید.");
    }, 1200);
  };

  const handleApprove = (id: string, userId: string) => {
    onApproveDocument(id);
    setKycLevel(KycLevel.LEVEL_2);
    alert("مدرک هویتی تایید گشت و کاربر به سطح کاربری ۲ ارتقا یافت.");
  };

  const handleReject = (id: string) => {
    if (!rejectReason) {
      alert("لطفاً علت رد مدرک را بنویسید.");
      return;
    }
    onRejectDocument(id, rejectReason);
    setKycLevel(KycLevel.LEVEL_0);
    setActiveRejectId(null);
    setRejectReason("");
    alert("مدرک با موفقیت رد گشت.");
  };

  return (
    <div className="space-y-8 text-right font-sans">
      
      {/* Top dashboard metrics row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        
        {/* Metric 1 */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow flex items-center justify-between">
          <div className="text-left">
            <p className="text-xl font-mono font-bold text-white">{metrics.activeUsers.toLocaleString()}</p>
            <p className="text-[10px] text-slate-500 mt-1">تعداد مبادله‌کنندگان فعال</p>
          </div>
          <div className="bg-amber-500/10 text-amber-500 p-3 rounded-xl">
            <Users className="h-5 w-5" />
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow flex items-center justify-between">
          <div className="text-left">
            <p className="text-xl font-mono font-bold text-white">
              {(metrics.totalTradingVolume / 10).toLocaleString("fa-IR")} <span className="text-[10px] font-sans">تومان</span>
            </p>
            <p className="text-[10px] text-slate-500 mt-1">حجم کل معاملات تالار</p>
          </div>
          <div className="bg-amber-500/10 text-amber-500 p-3 rounded-xl">
            <Coins className="h-5 w-5" />
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow flex items-center justify-between">
          <div className="text-left">
            <p className="text-xl font-mono font-bold text-emerald-400">
              {(metrics.commissionEarned / 10).toLocaleString("fa-IR")} <span className="text-[10px] font-sans">تومان</span>
            </p>
            <p className="text-[10px] text-slate-500 mt-1">درآمد ناخالص سیستم (کارمزد)</p>
          </div>
          <div className="bg-emerald-500/10 text-emerald-400 p-3 rounded-xl">
            <Percent className="h-5 w-5" />
          </div>
        </div>

        {/* Metric 4 */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow flex items-center justify-between">
          <div className="text-left">
            <p className="text-sm font-mono font-bold text-amber-500 mt-1">
              {new Date(metrics.lastBackup).toLocaleTimeString("fa-IR")}
            </p>
            <p className="text-[10px] text-slate-500">آخرین بکاپ موفق هر ۴ ساعت</p>
          </div>
          <div className="bg-amber-500/10 text-amber-500 p-3 rounded-xl">
            <Database className="h-5 w-5" />
          </div>
        </div>

      </div>

      {/* Main admin tables and schedulers */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* KYC Document approvals manager */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center justify-end gap-2">
            میز بررسی و ممیزی مدارک هویتی پلتفرم (Compliance Deck)
            <ShieldCheck className="h-4.5 w-4.5 text-amber-500" />
          </h3>
          <p className="text-xs text-slate-400">مدارک خام آپلود شده توسط کاربران برای دستیابی به مبادلات سطح ۲ نامحدود را بررسی و تایید کنید.</p>

          <div className="overflow-x-auto pt-2">
            {documents.length === 0 ? (
              <div className="text-center py-8 text-slate-500 text-xs">هیچ مدرکی برای ممیزی در صف انتظار قرار ندارد.</div>
            ) : (
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="text-slate-500 border-b border-slate-800 pb-2">
                    <th className="pb-2">شناسه مدرک</th>
                    <th className="pb-2">نوع مدارک</th>
                    <th className="pb-2">جزئیات محرز OCR شده</th>
                    <th className="pb-2">وضعیت تراشه</th>
                    <th className="pb-2 text-left">عملیات بررسی</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/40">
                  {documents.map((doc) => (
                    <tr key={doc.id} className="text-slate-300">
                      <td className="py-3 font-mono text-[11px] text-slate-400">{doc.id}</td>
                      <td className="py-3 font-medium">کارت ملی هوشمند جدید</td>
                      <td className="py-3 space-y-1">
                        <div className="text-slate-200 font-semibold">{doc.ocrExtractedName || "آپلود دستی"}</div>
                        <div className="text-[10px] font-mono text-slate-500">کدملی: {doc.ocrExtractedNationalId}</div>
                      </td>
                      <td className="py-3">
                        <span className={`inline-flex px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                          doc.status === DocStatus.APPROVED
                            ? "bg-emerald-500/10 text-emerald-400"
                            : doc.status === DocStatus.REJECTED
                            ? "bg-red-500/10 text-red-400"
                            : "bg-amber-500/10 text-amber-400 animate-pulse"
                        }`}>
                          {doc.status === DocStatus.APPROVED ? "تأیید شده" : doc.status === DocStatus.REJECTED ? "رد شده" : "در انتظار بررسی"}
                        </span>
                      </td>
                      <td className="py-3 text-left">
                        {doc.status === DocStatus.PENDING ? (
                          <div className="flex gap-2 justify-end">
                            <button
                              onClick={() => {
                                if(confirm("آیا با تایید این مدرک و ارتقاء حساب کاربر موافق هستید؟")) {
                                  handleApprove(doc.id, doc.userId);
                                }
                              }}
                              className="bg-emerald-500 text-slate-950 px-2.5 py-1 rounded text-[10px] font-bold"
                            >
                              تأیید مدارک
                            </button>
                            <button
                              onClick={() => setActiveRejectId(doc.id)}
                              className="bg-red-500/15 text-red-400 border border-red-500/20 px-2.5 py-1 rounded text-[10px] font-semibold"
                            >
                              رد مدرک
                            </button>
                          </div>
                        ) : (
                          <span className="text-[10px] text-slate-500 font-sans">بررسی شده</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          {/* Inline rejection reason form */}
          {activeRejectId && (
            <div className="bg-slate-950 p-4 rounded-xl border border-red-500/20 space-y-3 mt-4">
              <label className="block text-[11px] text-red-400 font-semibold">توضیح علت رد مدارک هویتی:</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={rejectReason}
                  onChange={(e) => setRejectReason(e.target.value)}
                  placeholder="مثلا: تار بودن تصویر کارت ملی یا مخدوش بودن کد ملی..."
                  className="flex-1 bg-slate-900 border border-slate-800 text-xs px-3 py-2 rounded-lg text-white text-right outline-none focus:border-red-500"
                  id="input-reject-reason"
                />
                <button
                  onClick={() => handleReject(activeRejectId)}
                  className="bg-red-500 text-white text-xs px-4 py-2 rounded-lg font-bold"
                  id="btn-confirm-reject-doc"
                >
                  ثبت رد فاکتور
                </button>
                <button
                  onClick={() => { setActiveRejectId(null); setRejectReason(""); }}
                  className="bg-slate-800 text-slate-300 text-xs px-3 py-2 rounded-lg"
                >
                  انصراف
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Database backup job console & rates managers */}
        <div className="lg:col-span-1 space-y-6">
          
          {/* Fee editor */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow space-y-3.5">
            <h4 className="text-xs font-bold text-white flex items-center justify-end gap-2">
              مدیریت تعرفه و کارمزد معاملات
              <Percent className="h-4 w-4 text-amber-500" />
            </h4>
            <p className="text-[11px] text-slate-500 leading-relaxed text-right">درصد کارمزد خدمات معاملاتی را بر حسب حجم و نوع اهرم به صورت پویا و لحظه‌ای در هارد تنظیم کنید.</p>

            <div className="space-y-3">
              <div>
                <label className="block text-xs text-slate-400 mb-1.5">کارمزد پایه تالار (کمیسیون بر مبنای طلا):</label>
                <div className="flex gap-2 items-center">
                  <span className="text-sm text-slate-400 font-mono">%</span>
                  <input
                    type="number"
                    step="0.01"
                    value={feePercent}
                    onChange={(e) => setFeePercent(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-sm text-white text-center font-mono focus:border-amber-500 outline-none"
                    id="input-fee-percent"
                  />
                </div>
              </div>

              <div className="text-[10px] text-slate-500 bg-slate-950 p-2.5 rounded border border-slate-850">
                ویرایش کارمزد بلافاصله در کل موتور تطبیق هسته معاملاتی اعمال شده و پورت معاملات بر مبنای {feePercent}% بسته‌بندی خواهد شد.
              </div>
            </div>
          </div>

          {/* DB Backups control console */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow space-y-3.5">
            <div className="flex items-center justify-between">
              <button
                onClick={handleManualBackup}
                disabled={isBackingUp}
                className="bg-amber-500 text-slate-950 hover:bg-amber-600 disabled:opacity-50 text-[10px] font-bold py-1.5 px-3 rounded-lg transition-all"
                id="btn-trigger-backup"
              >
                {isBackingUp ? "در حال پشتیبان‌گیری..." : "تهیه بکاپ آنی"}
              </button>
              <h4 className="text-xs font-bold text-white flex items-center gap-2">
                کنسول پشتیبان‌گیری دیتابیس PostgreSQL
                <Database className="h-4 w-4 text-amber-500" />
              </h4>
            </div>

            {/* Simulated Elastic Logs terminal */}
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 font-mono text-[9px] text-slate-400 text-left h-44 overflow-y-auto space-y-2 no-scrollbar">
              {backupLogs.map((log, idx) => (
                <div key={idx} className="leading-relaxed hover:text-white transition-colors duration-100">
                  {log}
                </div>
              ))}
            </div>

            <p className="text-[10px] text-slate-500 text-right leading-relaxed mt-1">
              * سیستم به صورت خودکار هر ۴ ساعت یک فایل رمزنگاری شده بکاپ کامل را در باکت امن S3 ابری بارگذاری می‌نماید (Celery crontab فعال).
            </p>
          </div>

        </div>

      </div>

    </div>
  );
}
