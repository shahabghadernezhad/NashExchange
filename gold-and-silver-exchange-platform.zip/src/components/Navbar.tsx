/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Coins, ShieldCheck, User, Zap, RefreshCw, LayoutDashboard } from "lucide-react";
import { KycLevel } from "../types";

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  kycLevel: KycLevel;
  fullName: string;
  rialBalance: number;
  rates: { GOLD_18K: number; GOLD_24K: number; SILVER: number; USDT_RIAL: number };
  onRefresh: () => void;
}

export default function Navbar({
  currentTab,
  setCurrentTab,
  kycLevel,
  fullName,
  rialBalance,
  rates,
  onRefresh
}: NavbarProps) {
  const tabs = [
    { id: "exchange", name: "صرافی آنلاین", icon: Coins },
    { id: "wallet", name: "کیف پول هوشمند", icon: ShieldCheck },
    { id: "kyc", name: "احراز هویت چندلایه", icon: User },
    { id: "physical", name: "انبارداری و تحویل فیزیکی", icon: RefreshCw },
    { id: "admin", name: "پنل ادمین", icon: LayoutDashboard },
    { id: "exporter", name: "دریافت کدهای بک‌اند (Django)", icon: Zap }
  ];

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white shadow-xl sticky top-0 z-50">
      {/* Real-time rates banner ticker */}
      <div className="bg-slate-950 text-xs py-1.5 px-4 border-b border-slate-800/60 overflow-hidden select-none">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4 text-slate-400 font-sans">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="font-sans font-medium text-[11px] text-slate-400">اتصال لحظه‌ای به سامانه صنف و وب‌ساکت فعال</span>
          </div>

          <div className="flex items-center gap-4 text-[11px]">
            <div>
              <span className="text-slate-500 ml-1">طلای ۱۸ عیار:</span>
              <span className="text-amber-500 font-semibold font-mono">
                {(rates.GOLD_18K / 10).toLocaleString("fa-IR")} <span className="text-[10px]">تومان</span>
              </span>
            </div>
            <div className="hidden sm:inline-block h-3 w-px bg-slate-800"></div>
            <div>
              <span className="text-slate-500 ml-1">طلای ۲۴ عیار:</span>
              <span className="text-amber-400 font-semibold font-mono">
                {(rates.GOLD_24K / 10).toLocaleString("fa-IR")} <span className="text-[10px]">تومان</span>
              </span>
            </div>
            <div className="hidden sm:inline-block h-3 w-px bg-slate-800"></div>
            <div>
              <span className="text-slate-500 ml-1">نقره خام:</span>
              <span className="text-slate-300 font-semibold font-mono">
                {(rates.SILVER / 10).toLocaleString("fa-IR")} <span className="text-[10px]">تومان</span>
              </span>
            </div>
            <div className="hidden sm:inline-block h-3 w-px bg-slate-800"></div>
            <div>
              <span className="text-slate-500 ml-1">تتر (USDT):</span>
              <span className="text-emerald-400 font-semibold font-mono">
                {(rates.USDT_RIAL / 10).toLocaleString("fa-IR")} <span className="text-[10px]">تومان</span>
              </span>
            </div>
          </div>

          <button
            onClick={onRefresh}
            className="text-slate-400 hover:text-white flex items-center gap-1 text-[11px] transition-colors"
            title="بروزرسانی دستی نرخ‌ها"
            id="btn-refresh-rates"
          >
            <RefreshCw className="h-3 w-3 animate-spin duration-1000" />
            <span className="hidden md:inline">بروزرسانی نرخ‌ها</span>
          </button>
        </div>
      </div>

      {/* Main Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex items-center justify-between flex-wrap gap-4">
          
          {/* Logo & Platform Name */}
          <div className="flex items-center gap-3">
            <div className="bg-amber-500/10 text-amber-500 p-2.5 rounded-xl border border-amber-500/30">
              <Coins className="h-7 w-7 text-amber-500" />
            </div>
            <div>
              <h1 className="text-lg font-extrabold text-white tracking-wide">سامانه مبادلات طلا و نقره زرین‌مهر</h1>
              <p className="text-[10px] text-amber-500/80 font-medium">پلتفرم هوشمند دیجیتال و فیزیکی طلا، نقره و شمش</p>
            </div>
          </div>

          {/* Nav Links */}
          <nav className="flex items-center gap-1.5 overflow-x-auto py-1 max-w-full no-scrollbar">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = currentTab === tab.id;
              return (
                <button
                  key={tab.id}
                  id={`nav-tab-${tab.id}`}
                  onClick={() => setCurrentTab(tab.id)}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-medium transition-all duration-200 whitespace-nowrap outline-none ${
                    isActive
                      ? "bg-amber-500 text-slate-950 font-semibold shadow-lg shadow-amber-500/20"
                      : "text-slate-300 hover:bg-slate-800/80 hover:text-white"
                  }`}
                >
                  <Icon className="h-4 w-4 shrink-0" />
                  <span>{tab.name}</span>
                </button>
              );
            })}
          </nav>

          {/* User Profile Summary */}
          <div className="flex items-center gap-3 bg-slate-950/60 p-2 rounded-xl border border-slate-800">
            <div className="text-right hidden sm:block">
              <p className="text-xs font-semibold text-slate-200">{fullName || "کاربر میهمان"}</p>
              <div className="flex items-center gap-1 justify-end mt-0.5">
                <span className={`w-1.5 h-1.5 rounded-full ${
                  kycLevel === KycLevel.LEVEL_2 ? "bg-emerald-500 animate-pulse" : kycLevel === KycLevel.LEVEL_1 ? "bg-amber-500" : "bg-red-500"
                }`}></span>
                <span className="text-[10px] text-slate-400 font-medium font-sans">
                  {kycLevel === KycLevel.LEVEL_2 ? "کاربر سطح ۲ (نامحدود)" : kycLevel === KycLevel.LEVEL_1 ? "کاربر سطح ۱" : "احراز هویت نشده"}
                </span>
              </div>
            </div>

            <div className="bg-slate-800 p-2 rounded-lg">
              <User className="h-4 w-4 text-slate-400" />
            </div>
          </div>

        </div>
      </div>
    </header>
  );
}
