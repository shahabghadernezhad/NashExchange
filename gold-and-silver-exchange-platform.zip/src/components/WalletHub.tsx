/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { CreditCard, Wallet, ArrowUpRight, ArrowDownLeft, RefreshCw, Filter, Calendar, Check, ExternalLink } from "lucide-react";
import { MetalType, Transaction, TransactionType, WalletBalances } from "../types";

interface WalletHubProps {
  balances: WalletBalances;
  rates: { GOLD_18K: number; GOLD_24K: number; SILVER: number; GOLD_INGOT: number; USDT_RIAL: number };
  transactions: Transaction[];
  onDepositRial: (amount: number) => void;
  onWithdrawRial: (amount: number) => void;
  onSwapUsdt: (usdtAmount: number, target: "rial" | MetalType) => void;
}

export default function WalletHub({
  balances,
  rates,
  transactions,
  onDepositRial,
  onWithdrawRial,
  onSwapUsdt
}: WalletHubProps) {
  const [filterType, setFilterType] = useState<string>("ALL");
  const [zarinpalOpen, setZarinpalOpen] = useState(false);
  const [depositAmount, setDepositAmount] = useState<number>(50000000); // 5 Million Toman default
  const [withdrawAmount, setWithdrawAmount] = useState<number>(10000000);
  const [usdtAmountToSwap, setUsdtAmountToSwap] = useState<number>(100);
  const [usdtTarget, setUsdtTarget] = useState<string>("rial");

  const [dateRange, setDateRange] = useState<string>("ALL"); // ALL, TODAY, WEEK

  // Filter transactions
  const filteredTxs = transactions.filter((tx) => {
    if (filterType !== "ALL" && tx.type !== filterType) return false;
    
    if (dateRange !== "ALL") {
      const txDate = new Date(tx.timestamp);
      const now = new Date();
      if (dateRange === "TODAY") {
        return txDate.toDateString() === now.toDateString();
      }
      if (dateRange === "WEEK") {
        const oneWeekAgo = new Date();
        oneWeekAgo.setDate(now.getDate() - 7);
        return txDate >= oneWeekAgo;
      }
    }
    return true;
  });

  const handleDepositClick = () => {
    // Open standard Zarinpal custom sandbox view
    setZarinpalOpen(true);
  };

  const confirmZarinpalPayment = () => {
    onDepositRial(depositAmount);
    setZarinpalOpen(false);
  };

  const handleWithdrawClick = () => {
    if (withdrawAmount > balances.rial) {
      alert("موجودی ریالی شما کافی نیست.");
      return;
    }
    onWithdrawRial(withdrawAmount);
    alert(`درخواست برداشت شما به مبلغ ${(withdrawAmount / 10).toLocaleString("fa-IR")} تومان با موفقیت ثبت شد و پایا گردید.`);
  };

  const handleUsdtSwapClick = () => {
    if (usdtAmountToSwap > balances.usdt) {
      alert("موجودی تتر پلتفرم شما کافی نیست.");
      return;
    }
    onSwapUsdt(usdtAmountToSwap, usdtTarget === "rial" ? "rial" : (usdtTarget as MetalType));
    alert(`مبلغ ${usdtAmountToSwap} تتر با موفقیت به مورد انتخابی بازخرید و تبدیل گردید.`);
  };

  // Human metal names
  const getMetalFarsi = (type?: MetalType) => {
    if (!type) return "";
    switch (type) {
      case MetalType.GOLD_18K: return "طلای ۱۸ عیار";
      case MetalType.GOLD_24K: return "طلای ۲۴ عیار";
      case MetalType.SILVER: return "نقره خام";
      case MetalType.GOLD_INGOT: return "شمش خالص";
    }
  };

  // Convert USDT values
  const getUsdtValueString = () => {
    const totalRial = usdtAmountToSwap * rates.USDT_RIAL;
    if (usdtTarget === "rial") {
      return `${(totalRial / 10).toLocaleString("fa-IR")} تومان`;
    }
    const targetPrice = rates[usdtTarget as MetalType] || 1;
    const targetGrams = totalRial / targetPrice;
    return `${targetGrams.toFixed(4)} گرم ${getMetalFarsi(usdtTarget as MetalType)}`;
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 text-right font-sans">
      
      {/* Wallet balances column */}
      <div className="lg:col-span-1 space-y-6">
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
          <h3 className="text-sm font-bold text-slate-400 flex items-center justify-end gap-2">
            موجودی کیف پول یکپارچه شما
            <Wallet className="h-4.5 w-4.5 text-amber-500" />
          </h3>

          {/* Rial Balance Card */}
          <div className="bg-gradient-to-br from-amber-500 to-amber-600 rounded-2xl p-5 text-slate-950 shadow-lg shadow-amber-500/10">
            <span className="text-[11px] font-bold text-slate-900/80">اعتبار ریالی کاربری</span>
            <div className="text-2xl font-extrabold font-mono mt-2 flex items-baseline justify-end gap-1">
              <span className="text-xs font-sans">تومان</span>
              <span>{(balances.rial / 10).toLocaleString("fa-IR")}</span>
            </div>
            <div className="mt-4 border-t border-slate-950/20 pt-3 flex items-center justify-between text-xs font-semibold text-slate-900/80">
              <span className="font-mono">{balances.usdt.toLocaleString()} USDT</span>
              <span>موجودی دلاری تتر:</span>
            </div>
          </div>

          {/* Metals Balances list */}
          <div className="space-y-3 pt-3">
            {[
              { type: MetalType.GOLD_18K, name: "طلای ۱۸ عیار", amount: balances.gold18k, color: "text-amber-500", rate: rates.GOLD_18K },
              { type: MetalType.GOLD_24K, name: "طلای ۲۴ عیار", amount: balances.gold24k, color: "text-amber-400", rate: rates.GOLD_24K },
              { type: MetalType.GOLD_INGOT, name: "شمش عیار خالص", amount: balances.ingot, color: "text-yellow-400", rate: rates.GOLD_INGOT },
              { type: MetalType.SILVER, name: "نقره صنعتی", amount: balances.silver, color: "text-slate-300", rate: rates.SILVER },
            ].map((metal) => {
              const currentVal = metal.amount * metal.rate;
              return (
                <div key={metal.type} className="bg-slate-950/50 hover:bg-slate-950 border border-slate-800/80 rounded-xl p-3.5 flex items-center justify-between transition-all">
                  <div className="text-left">
                    <p className="text-xs font-mono font-bold text-slate-200">{metal.amount.toFixed(4)} گرم</p>
                    <p className="text-[10px] text-slate-500 mt-0.5 font-sans">≈ {(currentVal / 10).toLocaleString("fa-IR")} تومان</p>
                  </div>
                  <div className="text-right">
                    <p className={`text-xs font-bold ${metal.color}`}>{metal.name}</p>
                    <p className="text-[10px] text-slate-500 mt-0.5">نرخ هر گرم: {(metal.rate / 10).toLocaleString("fa-IR")}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* USDT Instant Swapper */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
          <h3 className="text-sm font-bold text-slate-100 flex items-center justify-end gap-2">
            پرداخت و تبدیل مستقیم تتر به طلا / ریال
            <RefreshCw className="h-4.5 w-4.5 text-emerald-400" />
          </h3>
          <p className="text-xs text-slate-400 leading-relaxed">با وارد کردن حجم تتر، آن را به ریال یا هر یک از فلزات بدون واسطه و با پورسانت صفر تبدیل کنید.</p>

          <div className="space-y-4">
            <div>
              <label className="block text-xs text-slate-400 mb-1.5 font-medium">مقدار تتر جهت تعویض (USDT)</label>
              <input
                type="number"
                value={usdtAmountToSwap}
                onChange={(e) => setUsdtAmountToSwap(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm text-white focus:border-amber-500 focus:ring-1 focus:ring-amber-500 outline-none text-center font-mono"
                id="input-usdt-swap"
              />
              <span className="text-[10px] text-slate-500 mt-1 block">موجوی تتر حساب شما: {balances.usdt.toLocaleString()} USDT</span>
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1.5 font-medium">هدف تبدیل</label>
              <select
                value={usdtTarget}
                onChange={(e) => setUsdtTarget(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm text-white focus:border-amber-500 focus:ring-1 focus:ring-amber-500 outline-none text-right font-sans"
                id="select-usdt-target"
              >
                <option value="rial">کیف پول ریالی (تومان)</option>
                <option value={MetalType.GOLD_18K}>طلای ۱۸ عیار</option>
                <option value={MetalType.GOLD_24K}>طلای ۲۴ عیار</option>
                <option value={MetalType.GOLD_INGOT}>شمش طلا خالص</option>
                <option value={MetalType.SILVER}>نقره خام</option>
              </select>
            </div>

            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-center space-y-1">
              <span className="text-[10px] text-slate-500 block">شما تحویل می‌گیرید:</span>
              <span className="text-xs font-bold font-mono text-emerald-400">{getUsdtValueString()}</span>
            </div>

            <button
              onClick={handleUsdtSwapClick}
              className="w-full bg-emerald-500 hover:bg-emerald-600 text-slate-950 text-xs font-bold py-3.5 rounded-xl transition-all"
              id="btn-confirm-usdt-swap"
            >
              انجام مبادله ارزی تتر
            </button>
          </div>
        </div>
      </div>

      {/* Main deposit & withdraw options column */}
      <div className="lg:col-span-2 space-y-6">
        
        {/* Deposit / Withdraw Action Buttons */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Rial Deposit form */}
          <div className="space-y-4">
            <h4 className="text-sm font-bold text-white flex items-center justify-end gap-2">
              شارژ آنی موجودی ریالی
              <ArrowUpRight className="h-4.5 w-4.5 text-emerald-400" />
            </h4>
            <div className="space-y-3">
              <div>
                <label className="block text-xs text-slate-400 mb-1.5">مبلغ واریزی به تومان</label>
                <input
                  type="number"
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm text-white focus:border-amber-500 focus:ring-1 focus:ring-amber-500 outline-none text-center font-mono"
                  id="input-deposit-amount"
                />
              </div>

              {/* Suggestions */}
              <div className="flex gap-2 justify-end">
                {[10000000, 50000000, 100000000].map((v) => (
                  <button
                    key={v}
                    onClick={() => setDepositAmount(v)}
                    className="text-[10px] bg-slate-950 hover:bg-slate-800 px-2.5 py-1.5 rounded-lg border border-slate-800 text-slate-400"
                  >
                    {(v / 10).toLocaleString("fa-IR")} تومان
                  </button>
                ))}
              </div>

              <button
                onClick={handleDepositClick}
                className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-slate-950 text-xs font-bold py-3.5 rounded-xl transition-all shadow-lg shadow-emerald-500/10"
                id="btn-deposit-rial"
              >
                اتصال پرسرعت به زرین‌پال گیت‌وی
              </button>
            </div>
          </div>

          {/* Rial Cashout form */}
          <div className="space-y-4 border-t md:border-t-0 md:border-r border-slate-800 pt-6 md:pt-0 md:pr-6">
            <h4 className="text-sm font-bold text-white flex items-center justify-end gap-2">
              تسویه و برداشت شبا
              <ArrowDownLeft className="h-4.5 w-4.5 text-red-400" />
            </h4>
            <div className="space-y-3">
              <div>
                <label className="block text-xs text-slate-400 mb-1.5">مبلغ درخواستی به تومان</label>
                <input
                  type="number"
                  value={withdrawAmount}
                  onChange={(e) => setWithdrawAmount(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm text-white focus:border-amber-500 focus:ring-1 focus:ring-amber-500 outline-none text-center font-mono"
                  id="input-withdraw-amount"
                />
              </div>

              <button
                onClick={handleWithdrawClick}
                className="w-full bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold py-3.5 rounded-xl transition-all"
                id="btn-withdraw-rial"
              >
                برداشت از شبا شبیه‌سازی پایا
              </button>
            </div>
          </div>
        </div>

        {/* Filters and Ledger Log */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800/80 pb-4">
            <div className="flex items-center gap-1 bg-slate-950 px-2.5 py-1.5 rounded-xl border border-slate-800 text-[11px] self-end sm:self-center font-sans">
              <span className="text-slate-400 font-medium">کل نتایج فیلتر شده: {filteredTxs.length} مورد</span>
            </div>

            <div className="flex flex-wrap gap-2 justify-end">
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value)}
                className="bg-slate-950 border border-slate-800 text-[11px] text-slate-300 rounded-xl px-2.5 py-1.5 outline-none font-sans"
              >
                <option value="ALL">همه تراکنش‌ها</option>
                <option value={TransactionType.DEPOSIT_RIAL}>شارژ ریالی</option>
                <option value={TransactionType.WITHDRAW_RIAL}>برداشت ریالی</option>
                <option value={TransactionType.BUY_METAL}>خرید فلز</option>
                <option value={TransactionType.SELL_METAL}>فروش فلز</option>
                <option value={TransactionType.SWAP_USDT}>تبدیل تتر</option>
              </select>

              <select
                value={dateRange}
                onChange={(e) => setDateRange(e.target.value)}
                className="bg-slate-950 border border-slate-800 text-[11px] text-slate-300 rounded-xl px-2.5 py-1.5 outline-none font-sans"
              >
                <option value="ALL">همه بازه‌ها</option>
                <option value="TODAY">امروز</option>
                <option value="WEEK">۷ روز گذشته</option>
              </select>
            </div>
          </div>

          {/* Ledger Table */}
          <div className="overflow-x-auto">
            {filteredTxs.length === 0 ? (
              <div className="text-center py-8 text-slate-500 text-xs">تراکنشی با فیلترهای اعمال شده پیدا نشد.</div>
            ) : (
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="text-slate-500 border-b border-slate-800/80">
                    <th className="pb-3 pt-1 font-semibold">کد رهگیری</th>
                    <th className="pb-3 pt-1 font-semibold">جزئیات تراکنش</th>
                    <th className="pb-3 pt-1 font-semibold">ارزش ریالی (تومان)</th>
                    <th className="pb-3 pt-1 font-semibold">فلز / مقدار مربوطه</th>
                    <th className="pb-3 pt-1 font-semibold">وضعیت</th>
                    <th className="pb-3 pt-1 font-semibold text-left">تاریخ ثبت</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/50">
                  {filteredTxs.map((tx) => (
                    <tr key={tx.id} className="text-slate-300 hover:bg-slate-950/30 transition-colors">
                      <td className="py-3.5 font-mono text-[11px] font-semibold text-slate-400">{tx.id}</td>
                      <td className="py-3.5 font-medium">
                        {tx.type === TransactionType.DEPOSIT_RIAL && "شارژ پرداخت آنلاین"}
                        {tx.type === TransactionType.WITHDRAW_RIAL && "درخواست تسویه شبا"}
                        {tx.type === TransactionType.BUY_METAL && "خرید از تالار صرافی"}
                        {tx.type === TransactionType.SELL_METAL && "فروش در تالار صرافی"}
                        {tx.type === TransactionType.SWAP_USDT && "مبادله آنی تتر"}
                      </td>
                      <td className="py-3.5 font-mono font-bold text-slate-200">{(tx.amountRial / 10).toLocaleString("fa-IR")}</td>
                      <td className="py-3.5 font-sans">
                        {tx.amountMetal ? (
                          <span className="text-amber-500 font-semibold font-mono">
                            {tx.amountMetal} گرم {getMetalFarsi(tx.metalType)}
                          </span>
                        ) : (
                          <span className="text-slate-500">-</span>
                        )}
                      </td>
                      <td className="py-3.5">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold ${
                          tx.status === "SUCCESS"
                            ? "bg-emerald-500/10 text-emerald-400"
                            : tx.status === "PENDING"
                            ? "bg-amber-500/10 text-amber-400"
                            : "bg-red-500/10 text-red-400"
                        }`}>
                          {tx.status === "SUCCESS" ? "موفق" : tx.status === "PENDING" ? "در انتظار" : "ناموفق"}
                        </span>
                      </td>
                      <td className="py-3.5 font-mono text-[11px] text-slate-500 text-left">
                        {new Date(tx.timestamp).toLocaleString("fa-IR")}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </div>

      {/* Embedded Custom Zarinpal Gateway Overlay */}
      {zarinpalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/80 p-4 font-sans text-right backdrop-blur-sm">
          <div className="bg-slate-900 border border-amber-500/40 rounded-3xl max-w-md w-full overflow-hidden shadow-2xl">
            <div className="bg-amber-500 text-slate-950 p-5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="bg-slate-950 text-white rounded px-2 py-0.5 text-[9px] font-mono font-bold">SANDBOX</span>
                <span className="font-extrabold text-sm font-sans">درگاه الکترونیک پرداخت زرین‌پال</span>
              </div>
              <ExternalLink className="h-5 w-5 shrink-0" />
            </div>

            <div className="p-6 space-y-6">
              <div className="space-y-2">
                <p className="text-xs text-slate-400">فاکتور خرید بهینه‌سازی شده:</p>
                <div className="bg-slate-950 p-4 border border-slate-800 rounded-2xl space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="text-white font-mono font-bold">{(depositAmount / 10).toLocaleString("fa-IR")} تومان</span>
                    <span className="text-slate-400">مبلغ واریزی:</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-300">حق شارژ صرافی آنلاین</span>
                    <span className="text-slate-400">بابت:</span>
                  </div>
                  <div className="flex justify-between text-[11px]">
                    <span className="text-amber-500 font-mono font-semibold">#ZP-8812901-TR</span>
                    <span className="text-slate-500">شماره ارجاع تراکنش:</span>
                  </div>
                </div>
              </div>

              <div className="space-y-3.5">
                <div className="bg-amber-500/10 border border-amber-500/30 p-3.5 rounded-xl text-xs text-amber-400 leading-relaxed text-right flex gap-2">
                  <CreditCard className="h-5 w-5 shrink-0 text-amber-400 mt-0.5" />
                  <span>این یک درگاه تستی امن جهت تسهیل بررسی و ارزیابی است. تایید تراکنش حساب واقعی زرین‌مهر را شارژ می‌کند.</span>
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => setZarinpalOpen(false)}
                    className="flex-1 bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 py-3 rounded-xl transition-all"
                  >
                    لغو و بازگشت
                  </button>
                  <button
                    onClick={confirmZarinpalPayment}
                    className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-slate-950 text-xs font-bold py-3 rounded-xl transition-all"
                  >
                    تکمیل و بازگشت
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
