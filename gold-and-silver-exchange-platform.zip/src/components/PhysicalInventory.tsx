/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Hammer, Truck, ShieldAlert, Award, FileSpreadsheet, QrCode, CheckCircle2, Coins } from "lucide-react";
import { MetalType, PhysicalItem } from "../types";

interface PhysicalInventoryProps {
  rates: { GOLD_18K: number; GOLD_24K: number; SILVER: number; GOLD_INGOT: number };
  physicalItems: PhysicalItem[];
  walletBalances: { gold18k: number; gold24k: number; silver: number; ingot: number };
  onDeliveryRequest: (metalType: MetalType, weight: number) => void;
}

export default function PhysicalInventory({
  rates,
  physicalItems,
  walletBalances,
  onDeliveryRequest
}: PhysicalInventoryProps) {
  const [selectedMetal, setSelectedMetal] = useState<MetalType>(MetalType.GOLD_INGOT);
  const [deliveryWeight, setDeliveryWeight] = useState<number>(50); // Min 50g

  // Selected physical item to view details
  const [activeItem, setActiveItem] = useState<PhysicalItem | null>(physicalItems[0] || null);

  const getMetalFarsi = (type: MetalType) => {
    switch (type) {
      case MetalType.GOLD_18K: return "طلای ۱۸ عیار";
      case MetalType.GOLD_24K: return "طلای ۲۴ عیار";
      case MetalType.SILVER: return "نقره خام";
      case MetalType.GOLD_INGOT: return "شمش عیار خالص";
    }
  };

  const getWalletLimit = () => {
    switch (selectedMetal) {
      case MetalType.GOLD_18K: return walletBalances.gold18k;
      case MetalType.GOLD_24K: return walletBalances.gold24k;
      case MetalType.SILVER: return walletBalances.silver;
      case MetalType.GOLD_INGOT: return walletBalances.ingot;
    }
  };

  // Tax calculations
  // Gold base value + workmanship margin (اجرت ساخت: ~7%) + VAT (مالیات بر ارزش افزوده: 9% for workmanship/profit components)
  const basePricePerGram = rates[selectedMetal] || 1;
  const rawMetalWorth = basePricePerGram * deliveryWeight;
  const workmanshipPercent = 0.07; // 7% standard ingot audit/fabrication fee
  const workmanshipAmount = rawMetalWorth * workmanshipPercent;
  const vatAmount = workmanshipAmount * 0.09; // 9% tax applied legally to the workmanship
  const totalInvoice = rawMetalWorth + workmanshipAmount + vatAmount;

  const handleDeliverySubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (deliveryWeight < 50) {
      alert("حداقل وزن درخواستی برای ترخیص و ارسال فیزیکی شمش و طلا ۵۰ گرم می‌باشد.");
      return;
    }

    const available = getWalletLimit();
    if (deliveryWeight > available) {
      alert(`موجودی گرمی شما برای این فلز ناکافی است. موجودی فعلی: ${available.toFixed(3)} گرم.`);
      return;
    }

    onDeliveryRequest(selectedMetal, deliveryWeight);
    alert(`درخواست تسویه فیزیکی و فاکتور سازی شماره #INV-${Math.floor(10000+Math.random()*90000)} ثبت گشت. تخصیص کد انبار تعهدی در حال انجام است.`);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 text-right font-sans">
      
      {/* Physical Delivery Form builder column */}
      <div className="lg:col-span-1 space-y-6">
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center justify-end gap-2">
            درخواست ضرب و تحویل فیزیکی طلا و نقره
            <Truck className="h-4.5 w-4.5 text-amber-500" />
          </h3>
          <p className="text-xs text-slate-400 leading-relaxed">شمش طلا خود را با ضرب رسمی اتحادیه طلا تهران و دریافت حضوری ایمن یا ارسال بیمه شده مرسوله با پست پیشتاز تحویل بگیرید.</p>

          <form onSubmit={handleDeliverySubmit} className="space-y-4 pt-2">
            <div>
              <label className="block text-xs text-slate-400 mb-1.5 font-semibold">عنصر و خلوص تسویه</label>
              <select
                value={selectedMetal}
                onChange={(e) => setSelectedMetal(e.target.value as MetalType)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm text-white focus:border-amber-500 focus:ring-1 focus:ring-amber-500 outline-none text-right font-sans"
                id="select-delivery-metal"
              >
                <option value={MetalType.GOLD_INGOT}>شمش عیار خالص (۲۴ عیار)</option>
                <option value={MetalType.GOLD_24K}>طلای ۲۴ عیار صنف</option>
                <option value={MetalType.GOLD_18K}>طلای ۱۸ عیار</option>
                <option value={MetalType.SILVER}>نقره خام صنعتی</option>
              </select>
              <span className="text-[10px] text-amber-500 mt-1 block font-medium">موجودی گرمی کیف شما: {getWalletLimit().toFixed(3)} گرم</span>
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1.5 font-semibold">وزن ترخیص پیشنهادی (گرم - حداقل ۵۰ گرم)</label>
              <input
                type="number"
                min="50"
                value={deliveryWeight}
                onChange={(e) => setDeliveryWeight(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm text-white focus:border-amber-500 focus:ring-1 focus:ring-amber-500 outline-none text-center font-mono"
                id="input-delivery-weight"
              />
            </div>

            {/* Calculations review */}
            <div className="bg-slate-950 p-4 border border-slate-800 rounded-2xl space-y-2.5 text-xs text-slate-300">
              <div className="flex justify-between">
                <span className="font-mono text-slate-300">{(rawMetalWorth / 10).toLocaleString("fa-IR")} تومان</span>
                <span className="text-slate-500">ارزش خالص شمش:</span>
              </div>
              <div className="flex justify-between">
                <span className="font-mono text-slate-300">{(workmanshipAmount / 10).toLocaleString("fa-IR")} تومان</span>
                <span className="text-slate-500">اجرت حکاکی و ضرب تعهد صنف (۷٪):</span>
              </div>
              <div className="flex justify-between">
                <span className="font-mono text-slate-300">{(vatAmount / 10).toLocaleString("fa-IR")} تومان</span>
                <span className="text-slate-500">مالیات بر ارزش افزوده اجرت (۹٪):</span>
              </div>
              <div className="border-t border-slate-800/80 pt-2 flex justify-between font-bold text-amber-500">
                <span className="font-mono text-amber-500">{(totalInvoice / 10).toLocaleString("fa-IR")} تومان</span>
                <span>مبلغ نهایی تسویه با هزینه‌ها:</span>
              </div>
            </div>

            <div className="bg-amber-500/10 border border-amber-500/30 p-3 rounded-xl text-[11px] text-amber-400 leading-relaxed flex gap-2">
              <ShieldAlert className="h-4 w-4 shrink-0 text-amber-400 mt-0.5" />
              <span>مطابق مصوبه اتحادیه طلا تهران، فرآیند تسویه شمش پس از تایید فیزیکی ادمین، نیازمند تخصیص پپ‌کد رهگیری QR انبار است.</span>
            </div>

            <button
              type="submit"
              className="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-bold py-3.5 rounded-xl transition-all"
              id="btn-confirm-physical-delivery"
            >
              ثبت و صدور فاکتور ترخیص نهایی
            </button>
          </form>
        </div>
      </div>

      {/* Warehousing details and QR visualization column */}
      <div className="lg:col-span-2 space-y-6">
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800/80 pb-4">
            <h3 className="text-sm font-bold text-slate-200">فهرست شمش‌های سپرده‌گذاری شده شما در خزانه</h3>
            <span className="text-xs text-slate-400 font-semibold font-sans">تعداد موارد: {physicalItems.length} سند امانتی</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* List items */}
            <div className="space-y-3">
              {physicalItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveItem(item)}
                  className={`w-full p-4 rounded-2xl border text-right transition-all flex items-center justify-between ${
                    activeItem?.id === item.id 
                      ? "bg-slate-950 border-amber-500/55 shadow shadow-amber-500/10"
                      : "bg-slate-950/40 border-slate-800/80 hover:bg-slate-950"
                  }`}
                >
                  <div className="text-left">
                    <span className="font-mono font-bold text-xs text-slate-200">{item.weight} گرم</span>
                    <span className="block text-[10px] text-slate-500 mt-0.5 font-sans leading-none">{item.depotSection}</span>
                  </div>
                  <div>
                    <span className={`text-xs font-bold block ${
                      item.metalType === MetalType.SILVER ? "text-slate-300" : "text-amber-500"
                    }`}>
                      {getMetalFarsi(item.metalType)}
                    </span>
                    <span className="text-[10px] text-slate-500 mt-1 font-mono block leading-none">{item.id}</span>
                  </div>
                </button>
              ))}
            </div>

            {/* Code QR and Audit report card */}
            {activeItem && (
              <div className="bg-slate-950 border border-slate-800/80 rounded-2xl p-5 space-y-4 flex flex-col justify-between">
                <div className="space-y-2 border-b border-slate-800/60 pb-3">
                  <div className="flex items-center gap-1.5 justify-end text-xs font-bold text-white">
                    <span>جزئیات بازرسی محموله {activeItem.id}</span>
                    <Award className="h-4 w-4 text-amber-500" />
                  </div>
                  <p className="text-[10px] text-slate-500">نتایج ممیزی اتحادیه طلا و مسکوکات تهران روی گواهی اصالت سپرده:</p>
                </div>

                {/* Audit characteristics list */}
                <div className="space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="font-mono text-slate-300">{activeItem.id}</span>
                    <span className="text-slate-500">کد رهگیری شمش:</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-mono text-slate-300">{activeItem.weight} گرم</span>
                    <span className="text-slate-500">وزن ممیزی شده:</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-mono text-slate-300">{new Date(activeItem.auditDate).toLocaleDateString("fa-IR")}</span>
                    <span className="text-slate-500">آخرین پایش ممیزی:</span>
                  </div>
                  <div className="flex justify-between font-semibold text-emerald-400">
                    <span>ذخیره شده - بیمه رسمی صنف</span>
                    <span className="text-slate-500">وضعیت انبارداری:</span>
                  </div>
                </div>

                {/* Simulated Beautiful Grid-based QR Code */}
                <div className="flex flex-col items-center justify-center pt-3 border-t border-slate-800/50">
                  <div className="bg-white p-3.5 rounded-xl shadow-lg border border-slate-200">
                    {/* Unique layout using CSS boxes for simulated high-fidelity QR */}
                    <svg className="w-24 h-24 text-slate-900" viewBox="0 0 100 100">
                      {/* Corners layout */}
                      <rect x="0" y="0" width="25" height="25" fill="currentColor" />
                      <rect x="2" y="2" width="21" height="21" fill="white" />
                      <rect x="6" y="6" width="13" height="13" fill="currentColor" />

                      <rect x="75" y="0" width="25" height="25" fill="currentColor" />
                      <rect x="77" y="2" width="21" height="21" fill="white" />
                      <rect x="81" y="6" width="13" height="13" fill="currentColor" />

                      <rect x="0" y="75" width="25" height="25" fill="currentColor" />
                      <rect x="2" y="77" width="21" height="21" fill="white" />
                      <rect x="6" y="81" width="13" height="13" fill="currentColor" />

                      {/* Random QR bit squares */}
                      <rect x="40" y="10" width="8" height="8" fill="currentColor" />
                      <rect x="52" y="15" width="12" height="6" fill="currentColor" />
                      <rect x="45" y="30" width="15" height="10" fill="currentColor" />
                      <rect x="35" y="45" width="6" height="14" fill="currentColor" />
                      <rect x="65" y="45" width="15" height="15" fill="currentColor" />
                      <rect x="50" y="65" width="10" height="20" fill="currentColor" />
                      <rect x="15" y="35" width="15" height="8" fill="currentColor" />
                      <rect x="80" y="35" width="10" height="8" fill="currentColor" />
                      <rect x="80" y="80" width="10" height="10" fill="currentColor" />
                      <rect x="35" y="80" width="8" height="8" fill="currentColor" />
                    </svg>
                  </div>
                  <span className="text-[9px] text-slate-500 font-mono mt-2">{activeItem.qrCode}</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

    </div>
  );
}
