/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from "react";
import { Shield, Camera, FileText, CheckCircle2, AlertTriangle, Fingerprint, Upload, UserCheck, RefreshCw } from "lucide-react";
import { KycLevel, KycDocument, DocStatus } from "../types";

interface KYCPortalProps {
  kycLevel: KycLevel;
  setKycLevel: (level: KycLevel) => void;
  phone: string;
  setPhone: (p: string) => void;
  email: string;
  setEmail: (e: string) => void;
  fullName: string;
  setFullName: (n: string) => void;
  nationalId: string;
  setNationalId: (id: string) => void;
  documents: KycDocument[];
  addDocument: (doc: KycDocument) => void;
}

export default function KYCPortal({
  kycLevel,
  setKycLevel,
  phone,
  setPhone,
  email,
  setEmail,
  fullName,
  setFullName,
  nationalId,
  setNationalId,
  documents,
  addDocument,
}: KYCPortalProps) {
  const [step, setStep] = useState<"PHONE_EMAIL" | "DOC_UPLOAD" | "LIVENESS" | "VERIFICATION_COMPLETE">(
    kycLevel === KycLevel.LEVEL_2 ? "VERIFICATION_COMPLETE" : "PHONE_EMAIL"
  );

  const [localPhone, setLocalPhone] = useState(phone || "09123456789");
  const [localEmail, setLocalEmail] = useState(email || "shahabghadernezhad@gmail.com");
  const [localFullName, setLocalFullName] = useState(fullName || "شهاب قادرنژاد");
  const [localNationalId, setLocalNationalId] = useState(nationalId || "2870385382");

  const [uploadedCard, setUploadedCard] = useState<string | null>(null);
  const [isOcrScanning, setIsOcrScanning] = useState(false);
  const [ocrResults, setOcrResults] = useState<{ name: string; nationalId: string } | null>(null);

  const [cameraActive, setCameraActive] = useState(false);
  const [livenessScanning, setLivenessScanning] = useState(false);
  const [livenessProgress, setLivenessProgress] = useState(0);
  const [livenessSuccess, setLivenessSuccess] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  // Trigger webcamera frame for local liveness simulation
  const startCamera = async () => {
    setCameraActive(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { width: 400, height: 300 } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err) {
      console.warn("Camera could not be accessed, fallbacks activated", err);
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach((track) => track.stop());
    }
    setCameraActive(false);
  };

  const handleOcrSimulation = () => {
    if (!uploadedCard) return;
    setIsOcrScanning(true);
    setOcrResults(null);
    setTimeout(() => {
      setIsOcrScanning(false);
      // Auto-extract mock details matching Iranian card OCR behavior
      setOcrResults({
        name: localFullName || "شهاب قادرنژاد",
        nationalId: localNationalId || "2870385382",
      });
      // Set to main state
      setFullName(localFullName || "شهاب قادرنژاد");
      setNationalId(localNationalId || "2870385382");
    }, 2200);
  };

  const handleLivenessSimulation = () => {
    setLivenessScanning(true);
    setLivenessProgress(0);
    const interval = setInterval(() => {
      setLivenessProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setLivenessScanning(false);
          setLivenessSuccess(true);
          stopCamera();
          // Elevate user level to fully verified level 2!
          setKycLevel(KycLevel.LEVEL_2);
          setPhone(localPhone);
          setEmail(localEmail);
          
          // Inject document officially
          addDocument({
            id: `DOC-${Math.floor(10000 + Math.random() * 90000)}`,
            userId: "USR-001",
            type: "NATIONAL_CARD",
            fileUrl: uploadedCard || "https://images.unsplash.com/photo-1628157582853-a796fa650a6a?w=400",
            uploadDate: new Date().toISOString(),
            status: DocStatus.APPROVED,
            ocrExtractedName: localFullName,
            ocrExtractedNationalId: localNationalId,
          });
          
          setTimeout(() => {
            setStep("VERIFICATION_COMPLETE");
          }, 1500);
          return 100;
        }
        return prev + 10;
      });
    }, 150);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 text-right font-sans shadow-xl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800/80 pb-6 mb-8">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2 justify-end">
            دروازه احراز هویت چندلایه هوشمند (KYC/AML)
            <Shield className="h-6 w-6 text-amber-500 shrink-0" />
          </h2>
          <p className="text-xs text-slate-400 mt-1">تایید هویت خودکار مبتنی بر هوش مصنوعی، OCR متون و تست بیومتریک زنده برای پیشگیری از پولشویی</p>
        </div>

        {/* Level Status badges */}
        <div className="flex items-center gap-2 self-end md:self-center">
          <div className={`px-3 py-1.5 rounded-xl border text-xs font-semibold ${
            kycLevel === KycLevel.LEVEL_2 
              ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-400" 
              : kycLevel === KycLevel.LEVEL_1 
              ? "bg-amber-500/10 border-amber-500/30 text-amber-400"
              : "bg-red-500/10 border-red-500/30 text-red-400"
          }`}>
            سطح فعلی کاربری شما: {kycLevel === KycLevel.LEVEL_2 ? "سطح ۲ (نامحدود)" : kycLevel === KycLevel.LEVEL_1 ? "سطح ۱" : "سطح ۰ (غیر مجاز)"}
          </div>
        </div>
      </div>

      {/* Progress timeline */}
      <div className="grid grid-cols-4 gap-2 mb-8 relative max-w-xl mx-auto">
        <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-slate-800 -translate-y-1/2 z-0 hidden sm:block"></div>
        
        {[
          { id: "PHONE_EMAIL", label: "اطلاعات پایه", stepName: "PHONE_EMAIL" },
          { id: "DOC_UPLOAD", label: "بارگذاری مدارک", stepName: "DOC_UPLOAD" },
          { id: "LIVENESS", label: "تشخیص چهره زنده", stepName: "LIVENESS" },
          { id: "VERIFICATION_COMPLETE", label: "پایان و ارتقا", stepName: "VERIFICATION_COMPLETE" }
        ].map((s, idx) => {
          const isPassedOrActive = 
            (step === "PHONE_EMAIL" && idx === 0) ||
            (step === "DOC_UPLOAD" && idx <= 1) ||
            (step === "LIVENESS" && idx <= 2) ||
            (step === "VERIFICATION_COMPLETE");
            
          return (
            <div key={s.id} className="flex flex-col items-center text-center z-10">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold font-mono transition-all duration-300 ${
                isPassedOrActive ? "bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/30 font-extrabold" : "bg-slate-800 text-slate-500"
              }`}>
                {idx + 1}
              </div>
              <span className={`text-[11px] mt-2 font-medium ${isPassedOrActive ? "text-slate-200" : "text-slate-500"}`}>
                {s.label}
              </span>
            </div>
          );
        })}
      </div>

      {/* Step Contents */}
      {step === "PHONE_EMAIL" && (
        <div className="max-w-md mx-auto space-y-5">
          <div className="bg-slate-950/40 border border-slate-800/80 p-5 rounded-2xl flex items-start gap-3 text-sm text-slate-300">
            <Shield className="h-5 w-5 text-amber-500 shrink-0 mt-0.5" />
            <div className="text-right">
              <h3 className="font-semibold text-slate-100">احراز اطلاعات تماس اولیه</h3>
              <p className="text-xs text-slate-400 mt-1">تکمیل اطلاعات اولیه کاربری. سطح ۱ به شما اجازه خرید روزانه تا سقف ۱۰ گرم طلا خام را می‌دهد.</p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs text-slate-400 mb-1.5 font-medium">نام و نام خانوادگی (مطابق کارت ملی)</label>
              <input
                type="text"
                value={localFullName}
                onChange={(e) => setLocalFullName(e.target.value)}
                placeholder="مثال: شهاب قادرنژاد"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm text-white focus:border-amber-500 focus:ring-1 focus:ring-amber-500 outline-none text-right font-sans"
                id="input-kyc-fullname"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1.5 font-medium">کد ملی ده رقمی</label>
              <input
                type="text"
                value={localNationalId}
                onChange={(e) => setLocalNationalId(e.target.value)}
                placeholder="مثال: 2870385382"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm text-white focus:border-amber-500 focus:ring-1 focus:ring-amber-500 outline-none font-mono text-center tracking-widest"
                id="input-kyc-national-id"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-slate-400 mb-1.5 font-medium">شماره تلفن همراه</label>
                <input
                  type="tel"
                  value={localPhone}
                  onChange={(e) => setLocalPhone(e.target.value)}
                  placeholder="مثال: ۰۹۱۲۳۴۵۶۷۸۹"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm text-white focus:border-amber-500 focus:ring-1 focus:ring-amber-500 outline-none font-mono text-center"
                  id="input-kyc-phone"
                />
              </div>

              <div>
                <label className="block text-xs text-slate-400 mb-1.5 font-medium">آدرس ایمیل</label>
                <input
                  type="email"
                  value={localEmail}
                  onChange={(e) => setLocalEmail(e.target.value)}
                  placeholder="name@domain.com"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm text-white focus:border-amber-500 focus:ring-1 focus:ring-amber-500 outline-none font-sans text-left"
                  id="input-kyc-email"
                />
              </div>
            </div>
          </div>

          <button
            onClick={() => {
              setPhone(localPhone);
              setEmail(localEmail);
              setFullName(localFullName);
              setNationalId(localNationalId);
              // Set Level 1 automatically during basic verification
              setKycLevel(KycLevel.LEVEL_1);
              setStep("DOC_UPLOAD");
            }}
            className="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 text-sm font-bold py-3.5 rounded-xl transition-all shadow-lg shadow-amber-500/10 hover:shadow-amber-500/20"
            id="btn-kyc-step1-next"
          >
            تایید اطلاعات و بارگذاری مدارک هویت
          </button>
        </div>
      )}

      {step === "DOC_UPLOAD" && (
        <div className="max-w-lg mx-auto space-y-6">
          <div className="bg-slate-950/40 border border-slate-800/80 p-5 rounded-2xl">
            <h3 className="font-semibold text-slate-100 mb-1 text-sm">بارگذاری هویت هوشمند (مبتنی بر OCR)</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              تصویری واضح از روی کارت ملی جدید یا شناسنامه خود آپلود کنید. موتور پردازش تصویر سامانه زرین‌مهر، متن سند را اسکن کرده و با اطلاعات گام قبل مطابقت می‌دهد.
            </p>
          </div>

          <div className="space-y-4">
            <div className="border border-dashed border-slate-800 hover:border-amber-500/60 bg-slate-950/40 rounded-2xl p-6 transition-all">
              {!uploadedCard ? (
                <div className="flex flex-col items-center justify-center text-center space-y-4 py-4">
                  <div className="bg-slate-800 p-4 rounded-full">
                    <Upload className="h-6 w-6 text-slate-400" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-300 font-semibold mb-1">برای بارگذاری کارت ملی، تصویر را اینجا رها کنید یا کلیک کنید</p>
                    <p className="text-[10px] text-slate-500">فرمت‌های مجاز: JPG, PNG (حداکثر حجم: ۵ مگابایت)</p>
                  </div>
                  
                  {/* Click trigger simulation */}
                  <button
                    onClick={() => setUploadedCard("https://images.unsplash.com/photo-1628157582853-a796fa650a6a?w=400")}
                    className="bg-amber-500/10 text-amber-400 border border-amber-500/30 hover:bg-amber-500/20 text-[11px] px-4 py-2 rounded-lg transition-all"
                    id="btn-upload-national-card"
                  >
                    شبیه‌سازی فایل آپلود کارت ملی
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-800/50 pb-3">
                    <button 
                      onClick={() => { setUploadedCard(null); setOcrResults(null); }}
                      className="text-xs text-red-400 hover:text-red-300"
                    >
                      حذف فایل و تلاش مجدد
                    </button>
                    <span className="text-xs text-slate-400 font-medium">تصویر کارت ملی شهاب قادرنژاد_ملی.jpg</span>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-4 items-center justify-center">
                    <img
                      src={uploadedCard}
                      alt="کارت ملی"
                      className="h-28 w-44 object-cover rounded-xl border border-slate-800 shadow"
                    />

                    <div className="flex-1 space-y-2.5 text-center sm:text-right w-full">
                      <p className="text-xs text-slate-300 font-medium">موتور تحلیل متون امنیتی OCR:</p>
                      
                      {isOcrScanning ? (
                        <div className="flex items-center gap-2 justify-center sm:justify-end text-xs text-amber-400">
                          <RefreshCw className="h-4 w-4 animate-spin" />
                          <span>در حال استخراج داده از تراشه و متن سند کاربری...</span>
                        </div>
                      ) : ocrResults ? (
                        <div className="bg-slate-950 border border-emerald-500/20 p-2.5 rounded-xl space-y-1">
                          <div className="flex justify-between items-center text-[11px]">
                            <span className="text-emerald-400 font-semibold">{ocrResults.name}</span>
                            <span className="text-slate-500">:نام محرز شده</span>
                          </div>
                          <div className="flex justify-between items-center text-[11px]">
                            <span className="text-emerald-400 font-mono font-semibold">{ocrResults.nationalId}</span>
                            <span className="text-slate-500">:کد ملی محرز شده</span>
                          </div>
                        </div>
                      ) : (
                        <button
                          onClick={handleOcrSimulation}
                          className="w-full bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 py-2 rounded-lg transition-all font-semibold flex items-center justify-center gap-2"
                        >
                          <FileText className="h-3.5 w-3.5 text-amber-500" />
                          <span>تطبیق تصاویر با داده‌ی فیلد قبلی با OCR جدید</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="flex gap-4">
            <button
              onClick={() => setStep("PHONE_EMAIL")}
              className="flex-1 bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-300 py-3.5 rounded-xl transition-all"
            >
              بازگشت به اطلاعات پایه
            </button>
            <button
              onClick={() => {
                if (!uploadedCard) {
                  alert("لطفاً ابتدا سند شناسایی را آپلود کنید (یا شبیه‌سازی کنید)");
                  return;
                }
                setStep("LIVENESS");
                startCamera();
              }}
              className="flex-1 bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-bold py-3.5 rounded-xl transition-all"
            >
              گام بعدی: اسکن شناسایی هویت زنده (Liveness)
            </button>
          </div>
        </div>
      )}

      {step === "LIVENESS" && (
        <div className="max-w-lg mx-auto space-y-6">
          <div className="bg-slate-950/40 border border-slate-800/80 p-5 rounded-2xl text-right">
            <h3 className="font-semibold text-slate-100 text-sm mb-1">تشخیص بیومتریک زنده (Anti-Spoofing Liveness)</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              برای جلوگیری از جعل هویت با کارت‌های ایستا، چند ثانیه جلوی دوربین قرار بگیرید تا حرکات شبیه‌ساز پلک و زوایای فک اسکن گردند.
            </p>
          </div>

          <div className="relative flex flex-col items-center justify-center bg-slate-950 border border-slate-800 rounded-2xl p-4 overflow-hidden h-[300px]">
            {cameraActive ? (
              <video
                ref={videoRef}
                className="w-full h-full object-cover rounded-xl"
                playsInline
                muted
              />
            ) : (
              <div className="text-center text-slate-500 text-xs space-y-3">
                <Camera className="h-10 w-10 text-slate-600 mx-auto" />
                <p>در حال دستیابی به وب‌کم برای انجام تشخیص زنده بیومتریک...</p>
                <p className="text-[10px] text-slate-600">در صورت اجازه ندادن مرورگر به وبکم، با شبیه‌ساز ادامه دهید.</p>
              </div>
            )}

            {/* Simulated overlays with green brackets for biometric analysis */}
            <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
              <div className="h-44 w-44 rounded-full border-2 border-dashed border-amber-500/80 flex items-center justify-center">
                <div className="text-[10px] text-amber-500 font-mono -mt-16 bg-slate-900/90 px-2 py-0.5 rounded border border-amber-500/40">
                  {livenessScanning ? `در حال پردازش ${livenessProgress}%` : "چهره خود را مرکز قرار دهید"}
                </div>
              </div>
            </div>

            {livenessScanning && (
              <div className="absolute bottom-4 left-4 right-4 bg-slate-900/90 p-3 rounded-xl border border-amber-500/40 space-y-2">
                <div className="flex justify-between items-center text-xs text-slate-300">
                  <span className="font-mono">{livenessProgress}%</span>
                  <span>مکانیزم اسکن چشم‌ها و دهان...</span>
                </div>
                <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-amber-500 h-full transition-all duration-300" style={{ width: `${livenessProgress}%` }}></div>
                </div>
              </div>
            )}
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <button
              onClick={() => { stopCamera(); setStep("DOC_UPLOAD"); }}
              className="flex-1 bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 py-3 rounded-xl transition-all"
            >
              انصراف و تصحیح مدارک
            </button>

            {!cameraActive && (
              <button
                onClick={startCamera}
                className="flex-1 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-semibold text-white py-3 rounded-xl transition-all"
              >
                فعال‌سازی مجدد دوربین
              </button>
            )}

            <button
              onClick={handleLivenessSimulation}
              disabled={livenessScanning}
              className="flex-1 bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-slate-950 text-xs font-bold py-3 rounded-xl transition-all shadow shadow-amber-500/10"
              id="btn-liveness-start"
            >
              شروع اسکن بیومتریک زنده
            </button>
          </div>
        </div>
      )}

      {step === "VERIFICATION_COMPLETE" && (
        <div className="max-w-md mx-auto text-center space-y-6 py-6">
          <div className="h-16 w-16 bg-emerald-500/10 text-emerald-400 rounded-full flex items-center justify-center mx-auto border border-emerald-500/30">
            <UserCheck className="h-8 w-8" />
          </div>

          <div className="space-y-2">
            <h3 className="text-lg font-bold text-white">کیف پول مدرک شما تایید و فعال شد!</h3>
            <p className="text-xs text-slate-400 leading-relaxed px-4">
              احراز هویت بیومتریک چندلایه با موفقیت به اتمام رسید. حساب کاربری شما به <span className="text-emerald-400 font-bold">سطح ۲ (بدون محدودیت خرید و فروش)</span> ارتقا یافت.
            </p>
          </div>

          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 max-w-sm mx-auto space-y-2 text-right text-xs">
            <div className="flex justify-between pb-2 border-b border-slate-800/60">
              <span className="text-slate-300">{localFullName}</span>
              <span className="text-slate-500">مبادله‌کننده:</span>
            </div>
            <div className="flex justify-between pb-2 border-b border-slate-800/60">
              <span className="text-slate-300">{localNationalId}</span>
              <span className="text-slate-500">کد ملی تأیید شده:</span>
            </div>
            <div className="flex justify-between">
              <span className="text-emerald-400 font-bold">فعال و نامحدود</span>
              <span className="text-slate-500">وضعیت دسترسی:</span>
            </div>
          </div>

          <button
            onClick={() => setStep("PHONE_EMAIL")}
            className="text-xs text-slate-400 hover:text-white underline"
          >
            مشاهده جزییات امنیتی و ویرایش پروفایل تماس
          </button>
        </div>
      )}
    </div>
  );
}
