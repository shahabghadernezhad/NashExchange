/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { ArrowUpRight, ArrowDownLeft, TrendingUp, DollarSign, Percent, Settings, ShieldAlert, BadgePercent, Coins, HelpCircle } from "lucide-react";
import { MetalType, OrderType, OrderBookItem, Order, KycLevel } from "../types";
import { GENERATE_CANDLES, INITIAL_BIDS, INITIAL_ASKS } from "../data";

interface ExchangeTerminalProps {
  kycLevel: KycLevel;
  rialBalance: number;
  rates: { GOLD_18K: number; GOLD_24K: number; SILVER: number; GOLD_INGOT: number; USDT_RIAL: number };
  orders: Order[];
  onCreateOrder: (order: Omit<Order, "id" | "timestamp" | "status">) => void;
  onCancelOrder: (id: string) => void;
  balances: { gold18k: number; gold24k: number; silver: number; ingot: number };
}

export default function ExchangeTerminal({
  kycLevel,
  rialBalance,
  rates,
  orders,
  onCreateOrder,
  onCancelOrder,
  balances
}: ExchangeTerminalProps) {
  const [selectedMetal, setSelectedMetal] = useState<MetalType>(MetalType.GOLD_18K);
  const [orderType, setOrderType] = useState<OrderType>(OrderType.LIMIT);
  const [side, setSide] = useState<"BUY" | "SELL">("BUY");

  const [price, setPrice] = useState<number>(rates[MetalType.GOLD_18K]);
  const [quantity, setQuantity] = useState<number>(1); // In grams
  const [leverage, setLeverage] = useState<number>(1); // Leverage multiplier

  // Order Book state containing bids/asks fluctuating
  const [bids, setBids] = useState<OrderBookItem[]>(INITIAL_BIDS);
  const [asks, setAsks] = useState<OrderBookItem[]>(INITIAL_ASKS);

  // Candles list
  const [candles, setCandles] = useState<any[]>([]);

  // Adjust initial price when metal updates
  useEffect(() => {
    setPrice(rates[selectedMetal]);
    setCandles(GENERATE_CANDLES(rates[selectedMetal], 20));
  }, [selectedMetal, rates]);

  // Simulated WebSocket and Order Book price fluctuations
  useEffect(() => {
    const interval = setInterval(() => {
      // Fluctuate the orderbook prices slightly to emulate dynamic feeds
      const variation = (Math.random() - 0.5) * 50000;
      
      setBids((prevBids) => {
        return prevBids.map((bid, i) => {
          const newPrice = Math.round(rates[selectedMetal] - (i + 1) * 30000 + variation);
          return {
            price: newPrice,
            quantity: Math.max(0.1, Number((bid.quantity + (Math.random() - 0.5) * 0.5).toFixed(2))),
            total: Math.round(newPrice * bid.quantity)
          };
        }).sort((a,b) => b.price - a.price);
      });

      setAsks((prevAsks) => {
        return prevAsks.map((ask, i) => {
          const newPrice = Math.round(rates[selectedMetal] + (i + 1) * 30000 + variation);
          return {
            price: newPrice,
            quantity: Math.max(0.1, Number((ask.quantity + (Math.random() - 0.5) * 0.5).toFixed(2))),
            total: Math.round(newPrice * ask.quantity)
          };
        }).sort((a,b) => a.price - b.price);
      });
    }, 2500);

    return () => clearInterval(interval);
  }, [selectedMetal, rates]);

  // Calculated commissions (dynamic rate from 0.1% to 0.5% depending on leverage and level)
  const getCommissionRate = () => {
    // Standard tier: 0.35%, drops for Level 2 verification to 0.15%
    let base = kycLevel === KycLevel.LEVEL_2 ? 0.0015 : 0.0035;
    // Multiplied slightly with leverage risk (adds small safety risk margin)
    if (leverage > 1) {
      base += (leverage * 0.00005);
    }
    return Math.min(0.005, base);
  };

  const getMetalFarsi = (type: MetalType) => {
    switch (type) {
      case MetalType.GOLD_18K: return "طلای ۱۸ عیار";
      case MetalType.GOLD_24K: return "طلای ۲۴ عیار";
      case MetalType.SILVER: return "نقره خام";
      case MetalType.GOLD_INGOT: return "شمش عیار خالص";
    }
  };

  // Human level balances
  const getSelectedMetalBalance = () => {
    switch (selectedMetal) {
      case MetalType.GOLD_18K: return balances.gold18k;
      case MetalType.GOLD_24K: return balances.gold24k;
      case MetalType.SILVER: return balances.silver;
      case MetalType.GOLD_INGOT: return balances.ingot;
    }
  };

  const handleCreateOrderSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Check KYC thresholds
    if (kycLevel === KycLevel.LEVEL_0) {
      alert("قبل از انجام هر معاملاتی، لطفا ابتدا سطح تماس اطلاعات هویتی (KYC) خود را در تب مربوطه احراز نمایید.");
      return;
    }

    if (kycLevel === KycLevel.LEVEL_1 && side === "BUY" && quantity > 10) {
      alert("محدودیت سطح ۱: سقف خرید روزانه شما ۱۰ گرم می‌باشد. با تکمیل اسکن زنده چهره به سطح ۲ بدون محدودیت ارزی مبدل شوید.");
      return;
    }

    const valueRial = price * quantity;
    const comm = valueRial * getCommissionRate();
    const totalRequired = valueRial / leverage + comm;

    if (side === "BUY" && totalRequired > rialBalance) {
      alert(`موجودی ریالی معامله شما کم است. نیازمند حداقل ${(totalRequired/10).toLocaleString("fa-IR")} تومان اعتبار (شامل وجه تضمین اهرم و کارمزد) هستید.`);
      return;
    }

    if (side === "SELL" && quantity > getSelectedMetalBalance()) {
      alert(`اعتبار گرمی کافی از فلز ${getMetalFarsi(selectedMetal)} در کیف هوشمند ندارید.`);
      return;
    }

    onCreateOrder({
      metalType: selectedMetal,
      type: orderType,
      side,
      price,
      quantity,
      leverage,
    });

    alert("سفارش جدید شما با موفقیت در صف معاملات همتا‌به‌همتا تالار صرافی ثبت و تسویه گشت.");
  };

  // Render SVG Candles and sub charts
  const renderInteractiveChart = () => {
    if (candles.length === 0) return null;

    const chartHeight = 220;
    const rsiHeight = 60;
    const padding = 15;
    const maxVal = Math.max(...candles.map((c) => c.high));
    const minVal = Math.min(...candles.map((c) => c.low));
    const range = maxVal - minVal;

    // Map candles to SVG coordinates
    const width = 500;
    const candleWidth = (width - padding * 2) / candles.length;

    return (
      <div className="space-y-4">
        {/* Main Candlestick Chart */}
        <div className="relative bg-slate-950 p-2 rounded-2xl border border-slate-800/80 overflow-hidden">
          <div className="absolute top-2 right-2 flex items-center gap-4 text-[10px] text-slate-500 font-sans">
            <div>
              <span className="text-emerald-500 font-bold ml-1">RSI(14):</span>
              <span className="font-mono text-slate-300">{candles[candles.length - 1]?.rsi}</span>
            </div>
            <div>
              <span className="text-amber-500 font-bold ml-1">MACD:</span>
              <span className="font-mono text-slate-300">{candles[candles.length - 1]?.macd.toFixed(3)}</span>
            </div>
          </div>

          <svg viewBox={`0 0 ${width} ${chartHeight}`} className="w-full h-auto select-none overflow-visible">
            {/* Grid lines */}
            <line x1={0} y1={chartHeight * 0.25} x2={width} y2={chartHeight * 0.25} stroke="#1e293b" strokeDasharray="3,3" />
            <line x1={0} y1={chartHeight * 0.5} x2={width} y2={chartHeight * 0.5} stroke="#1e293b" strokeDasharray="3,3" />
            <line x1={0} y1={chartHeight * 0.75} x2={width} y2={chartHeight * 0.75} stroke="#1e293b" strokeDasharray="3,3" />

            {candles.map((c, i) => {
              const x = padding + i * candleWidth + candleWidth / 2;
              
              const yOpen = chartHeight - padding - ((c.open - minVal) / range) * (chartHeight - padding * 2);
              const yClose = chartHeight - padding - ((c.close - minVal) / range) * (chartHeight - padding * 2);
              const yHigh = chartHeight - padding - ((c.high - minVal) / range) * (chartHeight - padding * 2);
              const yLow = chartHeight - padding - ((c.low - minVal) / range) * (chartHeight - padding * 2);

              const isGreen = c.close >= c.open;
              const color = isGreen ? "#10b981" : "#ef4444";
              
              const rectH = Math.max(2, Math.abs(yOpen - yClose));
              const rectY = Math.min(yOpen, yClose);

              return (
                <g key={i}>
                  {/* Wick */}
                  <line x1={x} y1={yHigh} x2={x} y2={yLow} stroke={color} strokeWidth={1.5} />
                  {/* Body */}
                  <rect
                    x={x - candleWidth * 0.35}
                    y={rectY}
                    width={candleWidth * 0.7}
                    height={rectH}
                    fill={color}
                    rx={1}
                  />
                </g>
              );
            })}
          </svg>
        </div>

        {/* Technical Analysis Subcharts indices (RSI / MACD) */}
        <div className="grid grid-cols-2 gap-4">
          {/* RSI Widget Graph */}
          <div className="bg-slate-950 p-2.5 rounded-2xl border border-slate-800/80">
            <span className="text-[10px] text-slate-400 font-semibold block mb-1">اندیکاتور شاخص قدرت نسبی (RSI)</span>
            <svg viewBox={`0 0 240 ${rsiHeight}`} className="w-full h-auto">
              <rect x={0} y={rsiHeight * 0.3} width={240} height={rsiHeight * 0.4} fill="#fbbf24" fillOpacity={0.05} stroke="#334155" strokeWidth={0.5} />
              <path
                d={candles.reduce((path, c, i) => {
                  const x = 5 + i * (230 / candles.length);
                  const y = rsiHeight - 5 - (c.rsi / 100) * (rsiHeight - 10);
                  return `${path} ${i === 0 ? "M" : "L"} ${x} ${y}`;
                }, "")}
                fill="none"
                stroke="#10b981"
                strokeWidth={1.2}
              />
            </svg>
          </div>

          {/* MACD Histogram Widget */}
          <div className="bg-slate-950 p-2.5 rounded-2xl border border-slate-800/80">
            <span className="text-[10px] text-slate-400 font-semibold block mb-1">هیستوگرام واگرایی مکدی (MACD)</span>
            <svg viewBox={`0 0 240 ${rsiHeight}`} className="w-full h-auto">
              <line x1={0} y1={rsiHeight / 2} x2={240} y2={rsiHeight / 2} stroke="#334155" />
              {candles.map((c, i) => {
                const x = 5 + i * (230 / candles.length);
                const barH = c.macd * 15;
                const isGreen = barH >= 0;
                return (
                  <line
                    key={i}
                    x1={x}
                    y1={rsiHeight / 2}
                    x2={x}
                    y2={rsiHeight / 2 - barH}
                    stroke={isGreen ? "#10b981" : "#ef4444"}
                    strokeWidth={3}
                  />
                );
              })}
            </svg>
          </div>
        </div>
      </div>
    );
  };

  const currentFeesComm = price * quantity * getCommissionRate();

  return (
    <div className="grid grid-cols-1 xl:grid-cols-4 gap-8 text-right font-sans">
      
      {/* Trading details column (Order terminal) */}
      <div className="xl:col-span-1 bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl flex flex-col justify-between">
        <form onSubmit={handleCreateOrderSubmit} className="space-y-4">
          
          {/* Select metal category */}
          <div>
            <label className="block text-xs text-slate-400 mb-1.5 font-semibold">انتخاب فلز تالار مبادلات</label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { type: MetalType.GOLD_18K, name: "۱۸ عیار" },
                { type: MetalType.GOLD_24K, name: "۲۴ عیار" },
                { type: MetalType.GOLD_INGOT, name: "شمش خام" },
                { type: MetalType.SILVER, name: "نقره خام" },
              ].map((m) => (
                <button
                  key={m.type}
                  type="button"
                  onClick={() => setSelectedMetal(m.type)}
                  className={`py-1.5 px-2 rounded-xl text-xs font-semibold border transition-all ${
                    selectedMetal === m.type
                      ? "bg-amber-500/15 border-amber-500 text-amber-500"
                      : "bg-slate-950 border-slate-800 text-slate-400 hover:text-white"
                  }`}
                >
                  {m.name}
                </button>
              ))}
            </div>
          </div>

          {/* Buy or Sell switch */}
          <div className="bg-slate-950 p-1 rounded-xl border border-slate-800 flex gap-1">
            <button
              type="button"
              onClick={() => setSide("SELL")}
              className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${
                side === "SELL" 
                  ? "bg-red-500 text-white shadow-lg shadow-red-500/10" 
                  : "text-slate-500 hover:text-slate-300"
              }`}
            >
              فروش (Sell)
            </button>
            <button
              type="button"
              onClick={() => setSide("BUY")}
              className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${
                side === "BUY"
                  ? "bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/10"
                  : "text-slate-500 hover:text-slate-300"
              }`}
            >
              خرید (Buy)
            </button>
          </div>

          {/* Order Categories inside box */}
          <div className="flex gap-1 bg-slate-950 p-1.5 rounded-xl border border-slate-800/80">
            {[OrderType.LIMIT, OrderType.MARKET, OrderType.STOP_LOSS].map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setOrderType(t)}
                className={`flex-1 py-1 px-1 text-[10px] rounded font-semibold transition-all ${
                  orderType === t ? "bg-slate-800 text-amber-500" : "text-slate-500 hover:text-slate-300"
                }`}
              >
                {t === OrderType.LIMIT ? "حدی (Limit)" : t === OrderType.MARKET ? "بازار" : "Stop-Loss"}
              </button>
            ))}
          </div>

          {/* Inputs section */}
          <div className="space-y-3.5">
            {orderType !== OrderType.MARKET && (
              <div>
                <label className="block text-xs text-slate-400 mb-1.5">قیمت پیشنهادی (تومان بر گرم)</label>
                <input
                  type="number"
                  value={price / 10}
                  onChange={(e) => setPrice(Number(e.target.value) * 10)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-white text-center font-mono focus:border-amber-500 outline-none"
                  id="input-terminal-price"
                />
              </div>
            )}

            <div>
              <label className="block text-xs text-slate-400 mb-1.5 flex justify-between items-center">
                <span className="text-[10px] text-slate-500 font-medium">موجودی: {getSelectedMetalBalance().toFixed(4)} گرم</span>
                <span>مقدار طلا / نقره پیشنهادی (گرم)</span>
              </label>
              <input
                type="number"
                step="0.01"
                value={quantity}
                onChange={(e) => setQuantity(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-white text-center font-mono focus:border-amber-500 outline-none"
                id="input-terminal-quantity"
              />
            </div>

            {/* Leverage selector from 2x up to 100x */}
            <div>
              <label className="block text-xs text-slate-400 mb-1.5 flex justify-between items-center">
                <span className="text-[10px] font-mono text-amber-500 font-semibold">{leverage}x Mult</span>
                <span>اهرم معاملات تالار (Leverage)</span>
              </label>
              <input
                type="range"
                min="1"
                max="100"
                value={leverage}
                onChange={(e) => setLeverage(Number(e.target.value))}
                className="w-full h-1 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-amber-500"
                id="input-terminal-leverage"
              />
              <div className="flex justify-between text-[9px] text-slate-500 mt-1 font-mono">
                <span>100x</span>
                <span>50x</span>
                <span>20x</span>
                <span>5x</span>
                <span>1x (عادی)</span>
              </div>
            </div>
          </div>

          {/* Checkout review box */}
          <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800/80 space-y-2 text-xs">
            <div className="flex justify-between text-slate-400">
              <span className="font-mono text-slate-300">
                {((price * quantity) / 10).toLocaleString("fa-IR")} <span className="text-[10px]">تومان</span>
              </span>
              <span>ارزش کل دارایی:</span>
            </div>

            {leverage > 1 && (
              <div className="flex justify-between text-slate-400">
                <span className="font-mono text-emerald-400 font-semibold">
                  {((price * quantity) / leverage / 10).toLocaleString("fa-IR")} <span className="text-[10px]">تومان</span>
                </span>
                <span>وجه تضمین اهرم {leverage}x:</span>
              </div>
            )}

            <div className="flex justify-between text-slate-400">
              <span className="font-mono text-slate-300">
                {(getCommissionRate() * 100).toFixed(2)}%
              </span>
              <span>نرخ کارمزد بر اساس تراز:</span>
            </div>

            <div className="flex justify-between text-slate-400 pt-1.5 border-t border-slate-800/50">
              <span className="font-mono text-amber-500 font-bold">
                {((price * quantity / leverage + currentFeesComm) / 10).toLocaleString("fa-IR")} <span className="text-[10px]">تومان</span>
              </span>
              <span className="font-semibold text-slate-200">کل وجه مورد نیاز:</span>
            </div>
          </div>

          <button
            type="submit"
            className={`w-full py-3.5 rounded-xl text-xs font-bold transition-all ${
              side === "BUY"
                ? "bg-emerald-500 text-slate-950 hover:bg-emerald-600 shadow-md shadow-emerald-500/10"
                : "bg-red-500 text-white hover:bg-red-600 shadow-md shadow-red-500/10"
            }`}
            id="btn-submit-exchange-order"
          >
            {side === "BUY" ? "ثبت سفارش آنی خرید" : "ثبت سفارش آنی فروش"}
          </button>
        </form>

        <div className="text-[10px] text-slate-500 leading-relaxed text-right mt-4 pt-4 border-t border-slate-800/40">
          * کلیه معاملات اهرمی تحت نظارت قوانین تالار صرافی طلا و نقره زرین‌مهر بوده و احتمال کال‌مارجین در مارجین سطوح پایین وجود دارد.
        </div>
      </div>

      {/* Main charting and open orders column */}
      <div className="xl:col-span-2 space-y-6">
        
        {/* Indicators Candle chart container */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <span className="text-[10px] bg-slate-950 border border-slate-800 py-1 px-2.5 rounded text-amber-500 font-bold">
                {getMetalFarsi(selectedMetal)}
              </span>
              <h3 className="text-sm font-bold text-slate-200">نمودار تکنیکال قیمت و شاخص‌های آماری لحظه‌ای</h3>
            </div>
            
            <div className="flex gap-2 text-[10px] text-slate-400">
              <span className="px-2 py-0.5 rounded bg-slate-950/60 border border-slate-800">15M</span>
              <span className="px-2 py-0.5 rounded bg-amber-500/10 border border-amber-500/30 text-amber-500 font-semibold">1H</span>
              <span className="px-2 py-0.5 rounded bg-slate-950/60 border border-slate-800">1D</span>
            </div>
          </div>

          {/* Interactive Chart */}
          {renderInteractiveChart()}
        </div>

        {/* User's open ledger orders */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
          <h4 className="text-xs font-bold text-white">سفارشات باز مبادلاتی شما در صرافی آنلاین</h4>
          
          <div className="overflow-x-auto">
            {orders.length === 0 ? (
              <div className="text-center py-6 text-slate-500 text-xs font-sans">هیچ سفارش باز مبادلاتی در حال حاضر ندارید.</div>
            ) : (
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="text-slate-500 border-b border-slate-800/85">
                    <th className="pb-2">شناسه سفارش</th>
                    <th className="pb-2">مورد معامله</th>
                    <th className="pb-2">جهت</th>
                    <th className="pb-2">اهرم مابه</th>
                    <th className="pb-2">مبلغ بر گرم</th>
                    <th className="pb-2">مقدار (گرم)</th>
                    <th className="pb-2">عملیات ابطال</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/40">
                  {orders.map((ord) => (
                    <tr key={ord.id} className="text-slate-300">
                      <td className="py-2.5 font-mono text-slate-400">{ord.id}</td>
                      <td className="py-2.5 font-medium">{getMetalFarsi(ord.metalType)}</td>
                      <td className="py-2.5">
                        <span className={`font-semibold ${ord.side === "BUY" ? "text-emerald-400" : "text-red-400"}`}>
                          {ord.side === "BUY" ? "خرید" : "فروش"}
                        </span>
                      </td>
                      <td className="py-2.5 font-mono text-amber-500 font-semibold">{ord.leverage}x</td>
                      <td className="py-2.5 font-mono font-bold">{(ord.price / 10).toLocaleString("fa-IR")}</td>
                      <td className="py-2.5 font-mono">{ord.quantity}</td>
                      <td className="py-2.5">
                        <button
                          onClick={() => {
                            onCancelOrder(ord.id);
                            alert("سفارش با موفقیت کانپسل گردید.");
                          }}
                          className="text-[10px] text-red-400 hover:text-red-300 font-semibold"
                        >
                          ابطال سفارش
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </div>

      {/* Order Book Column (WebSocket simulated) */}
      <div className="xl:col-span-1 bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl flex flex-col justify-between">
        <div className="space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800/60 pb-3">
            <span className="text-[10px] text-slate-500">قیمت (تومان) / حجم</span>
            <h4 className="text-xs font-bold text-slate-200">دفتر سفارشات (Order Book)</h4>
          </div>

          {/* ASKS (Sells) Red rows */}
          <div className="space-y-1">
            {asks.slice(0, 5).reverse().map((ask, idx) => {
              const totalValDecimal = (ask.price / 10);
              return (
                <div key={idx} className="relative group overflow-hidden py-1 px-2 rounded hover:bg-red-500/10 flex justify-between items-center text-xs">
                  {/* Visual progress width representation */}
                  <div className="absolute inset-y-0 left-0 bg-red-500/5 pointer-events-none" style={{ width: `${Math.min(100, ask.quantity * 2.5)}%` }}></div>
                  <span className="font-mono text-stone-400 font-semibold text-[10px] z-10">{ask.quantity}</span>
                  <span className="font-mono text-red-400 font-bold text-[11px] z-10">{totalValDecimal.toLocaleString()}</span>
                </div>
              );
            })}
          </div>

          {/* Spread gap marker */}
          <div className="py-2 border-y border-slate-800/60 text-center bg-slate-950 font-mono text-xs text-amber-500 font-extrabold flex justify-around items-center">
            <TrendingUp className="h-4 w-4 text-amber-500" />
            <span>اسپرد تالار: {Math.round((asks[0]?.price - bids[0]?.price)/10).toLocaleString()} تومان</span>
          </div>

          {/* BIDS (Buys) Green rows */}
          <div className="space-y-1">
            {bids.slice(0, 5).map((bid, idx) => {
              const totalValDecimal = (bid.price / 10);
              return (
                <div key={idx} className="relative group overflow-hidden py-1 px-2 rounded hover:bg-emerald-500/15 flex justify-between items-center text-xs">
                  {/* Visual progress width representation */}
                  <div className="absolute inset-y-0 left-0 bg-emerald-500/5 pointer-events-none" style={{ width: `${Math.min(100, bid.quantity * 2.5)}%` }}></div>
                  <span className="font-mono text-stone-400 font-semibold text-[10px] z-10">{bid.quantity}</span>
                  <span className="font-mono text-emerald-400 font-bold text-[11px] z-10">{totalValDecimal.toLocaleString()}</span>
                </div>
              );
            })}
          </div>

        </div>

        <div className="bg-slate-950 p-3 rounded-2xl border border-slate-850 mt-5 space-y-2 text-right">
          <div className="flex items-center gap-1.5 justify-end text-[10px] text-amber-500 font-semibold">
            <span>درجه لغزش معامله پلتفرم</span>
            <Settings className="h-3 w-3" />
          </div>
          <p className="text-[9px] text-slate-500 leading-relaxed">
            سرعت بهینه‌سازی شده وب‌ساکت تالار جهت ارائه نوسانات زیر ثانیه بازار نقره و طلا فعال می‌باشد.
          </p>
        </div>
      </div>

    </div>
  );
}
