import { useEffect, useState } from "react";
import type { Market } from "../data/markets";
import { formatPrice, formatChange } from "../utils/format";

type Props = {
  markets: Market[];
};

export default function MarketTicker({ markets }: Props) {
  // شبیه‌سازی تغییر قیمت لحظه‌ای
  const [prices, setPrices] = useState<Record<string, number>>(() =>
    Object.fromEntries(markets.map((m) => [m.symbol, m.price]))
  );

  useEffect(() => {
    const interval = setInterval(() => {
      setPrices((prev) => {
        const next = { ...prev };
        markets.forEach((m) => {
          const variation = (Math.random() - 0.5) * 0.004; // 0.4% نوسان
          next[m.symbol] = prev[m.symbol] * (1 + variation);
        });
        return next;
      });
    }, 2500);
    return () => clearInterval(interval);
  }, [markets]);

  // دو برابر کردن آیتم‌ها برای اسکرول بی‌نهایت
  const tickerItems = [...markets, ...markets];

  return (
    <div className="border-y border-[#2B3139]/60 bg-[#0B0E11]/80 backdrop-blur">
      <div className="relative overflow-hidden">
        <div className="ticker-track flex gap-12 py-3.5">
          {tickerItems.map((m, i) => {
            const currentPrice = prices[m.symbol] || m.price;
            const isUp = currentPrice >= m.price;
            return (
              <div
                key={`${m.symbol}-${i}`}
                className="flex shrink-0 items-center gap-2.5"
              >
                <span className="text-sm font-bold text-white">{m.symbol}</span>
                <span className="text-sm font-medium text-[#B7BDC6]">
                  {formatPrice(currentPrice)}
                </span>
                <span
                  className={`text-xs font-semibold ${
                    isUp ? "text-[#2EB589]" : "text-[#F6465D]"
                  }`}
                >
                  {formatChange(m.change24h)}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
