import { useEffect, useState } from "react";
import { siteConfig } from "../config/site";

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 right-0 left-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-[#0B0E11]/95 backdrop-blur-lg border-b border-[#2B3139]/60 shadow-lg shadow-black/20"
          : "bg-[#0B0E11]/60 backdrop-blur-sm"
      }`}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 lg:px-8">
        {/* Logo */}
        <a href="#" className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-[#F0B90B] to-[#F8D33A] shadow-lg shadow-yellow-500/20">
            <svg viewBox="0 0 24 24" className="h-5 w-5 text-[#0B0E11]" fill="currentColor">
              <path d="M6 12 L10 8 L14 12 L10 16 Z" />
              <path d="M10 12 L14 8 L18 12 L14 16 Z" opacity="0.7" />
            </svg>
          </div>
          <span className="text-lg font-bold text-white">
            {siteConfig.brand.name}
          </span>
        </a>

        {/* Desktop Nav */}
        <nav className="hidden items-center gap-7 lg:flex">
          {siteConfig.navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="text-sm font-medium text-[#B7BDC6] transition-colors hover:text-[#F0B90B]"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Actions */}
        <div className="hidden items-center gap-3 lg:flex">
          <button className="rounded-lg px-4 py-2 text-sm font-medium text-[#B7BDC6] transition-colors hover:text-white">
            ورود
          </button>
          <button className="rounded-lg bg-gradient-to-l from-[#F0B90B] to-[#F8D33A] px-5 py-2 text-sm font-bold text-[#0B0E11] shadow-lg shadow-yellow-500/20 transition-all hover:shadow-yellow-500/40">
            ثبت نام
          </button>
        </div>

        {/* Mobile Menu Button */}
        <button
          onClick={() => setMenuOpen(!menuOpen)}
          className="rounded-lg p-2 text-white lg:hidden"
        >
          <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            {menuOpen ? (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            ) : (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            )}
          </svg>
        </button>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="border-t border-[#2B3139]/60 bg-[#0B0E11] lg:hidden">
          <nav className="flex flex-col gap-1 px-4 py-4">
            {siteConfig.navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setMenuOpen(false)}
                className="rounded-lg px-3 py-2.5 text-sm font-medium text-[#B7BDC6] transition-colors hover:bg-[#1E2329] hover:text-[#F0B90B]"
              >
                {link.label}
              </a>
            ))}
            <div className="mt-3 flex gap-2">
              <button className="flex-1 rounded-lg border border-[#2B3139] px-4 py-2.5 text-sm font-medium text-white">
                ورود
              </button>
              <button className="flex-1 rounded-lg bg-gradient-to-l from-[#F0B90B] to-[#F8D33A] px-4 py-2.5 text-sm font-bold text-[#0B0E11]">
                ثبت نام
              </button>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
