export default function CTA() {
  return (
    <section id="trade" className="bg-[#0B0E11] py-20">
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        <div className="relative overflow-hidden rounded-3xl border border-[#2B3139] bg-gradient-to-br from-[#181A20] via-[#1E2329] to-[#181A20] p-8 sm:p-12 lg:p-16">
          {/* Background Effects */}
          <div className="absolute -right-20 -top-20 h-80 w-80 rounded-full bg-[#F0B90B]/20 blur-3xl"></div>
          <div className="absolute -bottom-20 -left-20 h-80 w-80 rounded-full bg-[#F0B90B]/10 blur-3xl"></div>

          <div
            className="absolute inset-0 opacity-5"
            style={{
              backgroundImage: `radial-gradient(circle at 2px 2px, #F0B90B 1px, transparent 0)`,
              backgroundSize: "32px 32px",
            }}
          ></div>

          <div className="relative grid items-center gap-8 lg:grid-cols-2">
            <div>
              <h2 className="mb-4 text-3xl font-black leading-tight text-white sm:text-4xl lg:text-5xl">
                همین الان شروع کنید
                <br />
                <span className="bg-gradient-to-l from-[#F0B90B] to-[#F8D33A] bg-clip-text text-transparent">
                  اولین معامله شما
                </span>
              </h2>
              <p className="mb-6 text-base leading-8 text-[#B7BDC6] sm:text-lg">
                با ثبت نام در ۳۰ ثانیه، به بزرگترین بازار ارز دیجیتال ایران بپیوندید.
                ۱۰۰ هزار تومان هدیه خوش‌آمدگویی!
              </p>

              <div className="flex flex-col gap-3 sm:flex-row">
                <button className="rounded-xl bg-gradient-to-l from-[#F0B90B] to-[#F8D33A] px-8 py-4 text-base font-bold text-[#0B0E11] shadow-lg shadow-yellow-500/30 transition-all hover:shadow-yellow-500/50">
                  ثبت نام رایگان
                </button>
                <button className="rounded-xl border border-[#2B3139] bg-[#0B0E11]/50 px-8 py-4 text-base font-medium text-white backdrop-blur transition-all hover:border-[#F0B90B]/50">
                  دانلود اپلیکیشن
                </button>
              </div>
            </div>

            {/* Benefits List */}
            <div className="space-y-3">
              {[
                "احراز هویت سریع در کمتر از ۵ دقیقه",
                "پشتیبانی ۲۴ ساعته به زبان فارسی",
                "واریز و برداشت ریالی آنی",
                "کیف پول اختصاصی با امنیت بالا",
                "اپلیکیشن iOS و Android",
              ].map((item) => (
                <div
                  key={item}
                  className="flex items-center gap-3 rounded-xl border border-[#2B3139]/60 bg-[#0B0E11]/50 p-3.5 backdrop-blur"
                >
                  <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#2EB589]/15">
                    <svg className="h-4 w-4 text-[#2EB589]" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"/>
                    </svg>
                  </div>
                  <span className="text-sm font-medium text-white sm:text-base">
                    {item}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
