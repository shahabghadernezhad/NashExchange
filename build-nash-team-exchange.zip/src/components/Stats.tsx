import { siteConfig } from "../config/site";

export default function Stats() {
  return (
    <section className="bg-gradient-to-l from-[#181A20] via-[#1E2329] to-[#181A20] py-16">
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        <div className="grid grid-cols-2 gap-6 lg:grid-cols-4">
          {siteConfig.stats.map((s, i) => (
            <div
              key={s.label}
              className="text-center"
              style={{ animationDelay: `${i * 100}ms` }}
            >
              <div className="mb-2 bg-gradient-to-l from-[#F0B90B] to-[#F8D33A] bg-clip-text text-4xl font-black text-transparent sm:text-5xl">
                {s.value}
              </div>
              <div className="text-sm text-[#B7BDC6] sm:text-base">{s.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
