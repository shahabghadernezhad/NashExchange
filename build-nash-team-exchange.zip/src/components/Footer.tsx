import { siteConfig } from "../config/site";

export default function Footer() {
  return (
    <footer id="about" className="border-t border-[#2B3139]/60 bg-[#0B0E11] pt-16 pb-8">
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-5">
          {/* Brand */}
          <div className="lg:col-span-2">
            <a href="#" className="mb-4 flex items-center gap-2.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-[#F0B90B] to-[#F8D33A]">
                <svg viewBox="0 0 24 24" className="h-5 w-5 text-[#0B0E11]" fill="currentColor">
                  <path d="M6 12 L10 8 L14 12 L10 16 Z" />
                  <path d="M10 12 L14 8 L18 12 L14 16 Z" opacity="0.7" />
                </svg>
              </div>
              <span className="text-lg font-bold text-white">
                {siteConfig.brand.name}
              </span>
            </a>
            <p className="mb-5 max-w-sm text-sm leading-7 text-[#848E9C]">
              {siteConfig.brand.description}. با بیش از ۵ میلیون کاربر فعال، امن‌ترین
              پلتفرم معاملاتی در ایران.
            </p>

            {/* Socials */}
            <div className="flex gap-2">
              {Object.entries(siteConfig.socials).map(([key, url]) => {
                const iconMap: Record<string, React.ReactNode> = {
                  telegram: (
                    <path d="M9.78 18.65l.28-4.23 7.68-6.92c.34-.31-.07-.46-.52-.19L7.74 13.3 3.64 12c-.88-.25-.89-.86.2-1.3l15.97-6.16c.73-.33 1.43.18 1.15 1.3l-2.72 12.81c-.19.91-.74 1.13-1.5.71L12.6 16.3l-1.99 1.93c-.23.23-.42.42-.83.42z"/>
                  ),
                  instagram: (
                    <path d="M12 2.16c3.2 0 3.58 0 4.85.07 3.25.15 4.77 1.69 4.92 4.92.06 1.27.07 1.65.07 4.85 0 3.2 0 3.58-.07 4.85-.15 3.23-1.66 4.77-4.92 4.92-1.27.06-1.65.07-4.85.07-3.2 0-3.58 0-4.85-.07-3.26-.15-4.77-1.7-4.92-4.92-.06-1.27-.07-1.65-.07-4.85 0-3.2 0-3.58.07-4.85.15-3.23 1.66-4.77 4.92-4.92C8.42 2.16 8.8 2.16 12 2.16zM12 0C8.74 0 8.33 0 7.05.07 2.68.27.27 2.68.07 7.05.01 8.33 0 8.74 0 12s.01 3.67.07 4.95c.2 4.36 2.62 6.78 6.98 6.98C8.33 24 8.74 24 12 24s3.67-.01 4.95-.07c4.36-.2 6.78-2.62 6.98-6.98.06-1.28.07-1.69.07-4.95s-.01-3.67-.07-4.95c-.2-4.36-2.62-6.78-6.98-6.98C15.67.01 15.26 0 12 0zm0 5.84A6.16 6.16 0 1018.16 12 6.16 6.16 0 0012 5.84zM12 16a4 4 0 114-4 4 4 0 01-4 4zm6.41-11.85a1.44 1.44 0 11-1.44 1.44 1.44 1.44 0 011.44-1.44z"/>
                  ),
                  twitter: (
                    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                  ),
                  youtube: (
                    <path d="M23.498 6.186a3.016 3.016 0 00-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 00.502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 002.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 002.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
                  ),
                };
                return (
                  <a
                    key={key}
                    href={url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex h-10 w-10 items-center justify-center rounded-lg border border-[#2B3139] bg-[#181A20] text-[#848E9C] transition-all hover:border-[#F0B90B]/50 hover:bg-[#F0B90B]/10 hover:text-[#F0B90B]"
                  >
                    <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 24 24">
                      {iconMap[key]}
                    </svg>
                  </a>
                );
              })}
            </div>
          </div>

          {/* Links */}
          {[
            {
              title: "محصولات",
              links: ["خرید ارز", "فروش ارز", "صرافی", "کیف پول", "API"],
            },
            {
              title: "خدمات",
              links: ["استیکینگ", "مارجین", "فیوچرز", "ایردراپ", "NFT"],
            },
            {
              title: "پشتیبانی",
              links: ["تماس با ما", "سوالات متداول", "قوانین", "حریم خصوصی", "آموزش"],
            },
          ].map((col) => (
            <div key={col.title}>
              <h3 className="mb-4 text-sm font-bold text-white">{col.title}</h3>
              <ul className="space-y-2.5">
                {col.links.map((link) => (
                  <li key={link}>
                    <a
                      href="#"
                      className="text-sm text-[#848E9C] transition-colors hover:text-[#F0B90B]"
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Contact Info */}
        <div className="mt-10 flex flex-col gap-3 border-t border-[#2B3139]/60 pt-6 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-[#848E9C]">
            <span>📧 {siteConfig.brand.email}</span>
            <span>📞 {siteConfig.brand.phone}</span>
            <span>📍 {siteConfig.brand.address}</span>
          </div>
        </div>

        {/* Copyright */}
        <div className="mt-6 text-center text-xs text-[#5E6673]">
          © ۱۴۰۳ {siteConfig.brand.name} — تمامی حقوق محفوظ است.
        </div>
      </div>
    </footer>
  );
}
