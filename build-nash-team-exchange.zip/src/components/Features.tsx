import type { ReactNode } from "react";
import { siteConfig } from "../config/site";

const iconMap: Record<string, ReactNode> = {
  shield: (
    <path d="M12 2L3 7v6c0 5 3 8 7 9 4-1 7-4 7-9V7l-7-5zm0 4.5l4 2.5v4c0 3-2 5-4 6-2-1-4-3-4-6V9l4-2.5z" />
  ),
  zap: (
    <path d="M13 2L3 14h7l-2 8 11-13h-7l1-7z" />
  ),
  trending: (
    <path d="M21 7l-4-4-4 4 1.4 1.4L13 9.8V3h-2v6.8L9.6 8.4 8 10l5 5 5-5-1.4-1.4L19.6 6.4 21 7zM3 17h18v2H3v-2z" />
  ),
  globe: (
    <path d="M12 2a10 10 0 100 20 10 10 0 000-20zm6.93 6h-3.05c-.32-1.25-.78-2.4-1.38-3.4 1.84.62 3.34 1.85 4.43 3.4zM12 4.04c.83 1.2 1.48 2.53 1.91 3.96h-3.82c.43-1.43 1.08-2.76 1.91-3.96zM4.26 14C4.1 13.36 4 12.69 4 12s.1-1.36.26-2h3.38c-.08.66-.14 1.32-.14 2 0 .68.06 1.34.14 2H4.26zm.82 2h3.05c.32 1.25.78 2.4 1.38 3.4-1.84-.62-3.34-1.85-4.43-3.4zM8.03 8H5.08c1.09-1.55 2.59-2.78 4.43-3.4-.6 1-1.06 2.15-1.38 3.4H8.03zM12 19.96c-.83-1.2-1.48-2.53-1.91-3.96h3.82c-.43 1.43-1.08 2.76-1.91 3.96zM14.34 14H9.66c-.09-.66-.16-1.32-.16-2 0-.68.07-1.34.16-2h4.68c.09.66.16 1.32.16 2 0 .68-.07 1.34-.16 2zm.25 5.4c.6-1 1.06-2.15 1.38-3.4h2.95c-1.09 1.55-2.59 2.78-4.43 3.4zM16.36 14c.08-.66.14-1.32.14-2 0-.68-.06-1.34-.14-2h3.38c.16.64.26 1.31.26 2s-.1 1.36-.26 2h-3.38z" />
  ),
  users: (
    <path d="M9 12c2.21 0 4-1.79 4-4S11.21 4 9 4 5 5.79 5 8s1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4zm9-2c1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3 1.34 3 3 3zm0 2c-.34 0-.67.03-1 .08 1.16.84 1.97 1.97 2 3.42V18h4v-2c0-2-3-4-5-4z" />
  ),
  award: (
    <path d="M12 2L9 5H5v4l-3 3 3 3v4h4l3 3 3-3h4v-4l3-3-3-3V5h-4l-3-3zm0 4a6 6 0 110 12 6 6 0 010-12zm0 2a4 4 0 100 8 4 4 0 000-8z" />
  ),
};

export default function Features() {
  return (
    <section id="features" className="relative bg-[#0B0E11] py-20">
      <div className="absolute inset-0 -z-10 opacity-30">
        <div className="absolute right-0 top-0 h-72 w-72 rounded-full bg-[#F0B90B]/5 blur-3xl"></div>
      </div>

      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        {/* Section Header */}
        <div className="mb-14 text-center">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-[#F0B90B]/30 bg-[#F0B90B]/5 px-4 py-1.5 text-xs font-medium text-[#F0B90B]">
            چرا ما؟
          </div>
          <h2 className="mb-3 text-3xl font-black text-white sm:text-4xl">
            چرا {siteConfig.brand.name} را انتخاب کنیم؟
          </h2>
          <p className="mx-auto max-w-2xl text-[#B7BDC6]">
            ما بهترین امکانات را برای یک تجربه معاملاتی بی‌نقص فراهم کرده‌ایم
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {siteConfig.features.map((f, i) => (
            <div
              key={f.title}
              className="group relative overflow-hidden rounded-2xl border border-[#2B3139] bg-gradient-to-br from-[#181A20] to-[#0B0E11] p-6 transition-all hover:border-[#F0B90B]/50 hover:shadow-xl hover:shadow-yellow-500/5"
              style={{ animationDelay: `${i * 50}ms` }}
            >
              <div className="absolute -right-12 -top-12 h-32 w-32 rounded-full bg-[#F0B90B]/0 blur-2xl transition-all group-hover:bg-[#F0B90B]/10"></div>

              <div className="relative">
                <div className="mb-5 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-[#F0B90B]/20 to-[#F0B90B]/5 text-[#F0B90B] ring-1 ring-[#F0B90B]/20">
                  <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
                    {iconMap[f.icon] || iconMap.shield}
                  </svg>
                </div>
                <h3 className="mb-2 text-lg font-bold text-white">{f.title}</h3>
                <p className="text-sm leading-7 text-[#B7BDC6]">
                  {f.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
