import { useState } from "react";
import type { Market } from "../data/markets";
import { formatPrice, formatCompact, formatChange } from "../utils/format";

type Props = {
  markets: Market[];
};

type SortKey = "rank" | "name" | "price" | "change24h" | "volume24h" | "marketCap";

export default function MarketTable({ markets }: Props) {
  const [filter, setFilter] = useState<"all" | "gainers" | "losers">("all");
  const [sortKey, setSortKey] = useState<SortKey>("rank");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("asc");

  const filtered = markets.filter((m) => {
    if (filter === "gainers") return m.change24h > 0;
    if (filter === "losers") return m.change24h < 0;
    return true;
  });

  const sorted = [...filtered].sort((a, b) => {
    const aVal = a[sortKey];
    const bVal = b[sortKey];
    if (typeof aVal === "number" && typeof bVal === "number") {
      return sortDir === "asc" ? aVal - bVal : bVal - aVal;
    }
    return sortDir === "asc"
      ? String(aVal).localeCompare(String(bVal))
      : String(bVal).localeCompare(String(aVal));
  });

  const handleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDir(sortDir === "asc" ? "desc" : "asc");
    } else {
      setSortKey(key);
      setSortDir("asc");
    }
  };

  const SortIcon = ({ k }: { k: SortKey }) => {
    if (sortKey !== k)
      return (
        <span className="text-[#848E9C] opacity-0 group-hover:opacity-100">↕</span>
      );
    return <span className="text-[#F0B90B]">{sortDir === "asc" ? "↑" : "↓"}</span>;
  };

  return (
    <section id="markets" className="bg-[#0B0E11] py-20">
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        {/* Section Header */}
        <div className="mb-10 text-center">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-[#F0B90B]/30 bg-[#F0B90B]/5 px-4 py-1.5 text-xs font-medium text-[#F0B90B]">
            بازارهای زنده
          </div>
          <h2 className="mb-3 text-3xl font-black text-white sm:text-4xl">
            قیمت لحظه‌ای ارزهای دیجیتال
          </h2>
          <p className="mx-auto max-w-2xl text-[#B7BDC6]">
            قیمت‌ها به صورت لحظه‌ای به‌روزرسانی می‌شوند. با بهترین نقدینگی، معامله کنید.
          </p>
        </div>

        {/* Filters */}
        <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
          <div className="flex gap-1 rounded-xl border border-[#2B3139] bg-[#181A20] p-1">
            {[
              { key: "all", label: "همه" },
              { key: "gainers", label: "برندگان" },
              { key: "losers", label: "بازندگان" },
            ].map((f) => (
              <button
                key={f.key}
                onClick={() => setFilter(f.key as typeof filter)}
                className={`rounded-lg px-4 py-1.5 text-sm font-medium transition-all ${
                  filter === f.key
                    ? "bg-[#F0B90B] text-[#0B0E11]"
                    : "text-[#B7BDC6] hover:text-white"
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 text-xs text-[#848E9C]">
            <span className="h-2 w-2 animate-pulse rounded-full bg-[#2EB589]"></span>
            <span>بروزرسانی خودکار</span>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto rounded-2xl border border-[#2B3139] bg-[#181A20] shadow-xl shadow-black/20">
          <table className="w-full min-w-[800px] text-right">
            <thead>
              <tr className="border-b border-[#2B3139] text-xs uppercase tracking-wider text-[#848E9C]">
                <th className="cursor-pointer px-4 py-4 font-medium" onClick={() => handleSort("rank")}>
                  <div className="group flex items-center gap-1"># <SortIcon k="rank" /></div>
                </th>
                <th className="cursor-pointer px-4 py-4 font-medium" onClick={() => handleSort("name")}>
                  <div className="group flex items-center gap-1">نام <SortIcon k="name" /></div>
                </th>
                <th className="cursor-pointer px-4 py-4 text-left font-medium" onClick={() => handleSort("price")}>
                  <div className="group flex items-center justify-end gap-1">قیمت <SortIcon k="price" /></div>
                </th>
                <th className="cursor-pointer px-4 py-4 text-left font-medium" onClick={() => handleSort("change24h")}>
                  <div className="group flex items-center justify-end gap-1">تغییر ۲۴h <SortIcon k="change24h" /></div>
                </th>
                <th className="cursor-pointer px-4 py-4 text-left font-medium" onClick={() => handleSort("volume24h")}>
                  <div className="group flex items-center justify-end gap-1">حجم ۲۴h <SortIcon k="volume24h" /></div>
                </th>
                <th className="cursor-pointer px-4 py-4 text-left font-medium" onClick={() => handleSort("marketCap")}>
                  <div className="group flex items-center justify-end gap-1">ارزش بازار <SortIcon k="marketCap" /></div>
                </th>
                <th className="px-4 py-4 text-left font-medium">عملیات</th>
              </tr>
            </thead>
            <tbody>
              {sorted.map((m) => {
                const isUp = m.change24h >= 0;
                return (
                  <tr
                    key={m.symbol}
                    className="border-b border-[#2B3139]/40 transition-colors hover:bg-[#1E2329]/40"
                  >
                    <td className="px-4 py-4 text-sm text-[#848E9C]">
                      {formatPrice(m.rank)}
                    </td>
                    <td className="px-4 py-4">
                      <div className="flex items-center gap-3">
                        <div
                          className="flex h-9 w-9 items-center justify-center rounded-full text-base font-bold text-white shadow-md"
                          style={{
                            background: `linear-gradient(135deg, ${m.color}, ${m.color}99)`,
                          }}
                        >
                          {m.icon}
                        </div>
                        <div>
                          <div className="text-sm font-bold text-white">{m.name}</div>
                          <div className="text-xs text-[#848E9C]">{m.pair}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-4 text-left text-sm font-medium text-white">
                      {formatPrice(m.price)}
                    </td>
                    <td className="px-4 py-4 text-left">
                      <span
                        className={`inline-flex items-center gap-1 rounded-md px-2 py-1 text-xs font-bold ${
                          isUp
                            ? "bg-[#2EB589]/15 text-[#2EB589]"
                            : "bg-[#F6465D]/15 text-[#F6465D]"
                        }`}
                      >
                        {isUp ? "▲" : "▼"} {formatChange(m.change24h)}
                      </span>
                    </td>
                    <td className="px-4 py-4 text-left text-sm text-[#B7BDC6]">
                      {formatCompact(m.volume24h)}
                    </td>
                    <td className="px-4 py-4 text-left text-sm text-[#B7BDC6]">
                      {formatCompact(m.marketCap)}
                    </td>
                    <td className="px-4 py-4 text-left">
                      <button className="rounded-lg bg-gradient-to-l from-[#F0B90B] to-[#F8D33A] px-3 py-1.5 text-xs font-bold text-[#0B0E11] transition-all hover:shadow-lg hover:shadow-yellow-500/30">
                        معامله
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}
