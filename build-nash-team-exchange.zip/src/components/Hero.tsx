import { siteConfig } from "../config/site";

export default function Hero() {
  return (
    <section className="relative overflow-hidden pt-32 pb-20 lg:pt-40 lg:pb-28">
      {/* Background Effects */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-1/4 right-1/4 h-96 w-96 rounded-full bg-[#F0B90B]/10 blur-3xl"></div>
        <div className="absolute bottom-1/4 left-1/4 h-96 w-96 rounded-full bg-[#F0B90B]/5 blur-3xl"></div>
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `linear-gradient(#F0B90B 1px, transparent 1px), linear-gradient(90deg, #F0B90B 1px, transparent 1px)`,
            backgroundSize: "60px 60px",
          }}
        ></div>
      </div>

      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          {/* Left Content */}
          <div className="text-center lg:text-right">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-[#F0B90B]/30 bg-[#F0B90B]/5 px-4 py-1.5">
              <span className="h-2 w-2 animate-pulse rounded-full bg-[#F0B90B]"></span>
              <span className="text-xs font-medium text-[#F0B90B]">
                پلتفرم شماره ۱ ایران
              </span>
            </div>

            <h1 className="mb-6 text-4xl font-black leading-tight text-white sm:text-5xl lg:text-6xl">
              آینده را با{" "}
              <span className="bg-gradient-to-l from-[#F0B90B] to-[#F8D33A] bg-clip-text text-transparent">
                {siteConfig.brand.name}
              </span>{" "}
              <br />
              معامله کنید
            </h1>

            <p className="mb-8 text-base leading-8 text-[#B7BDC6] sm:text-lg lg:text-xl">
              {siteConfig.brand.description}. با امنیت بالا، کارمزد کم و
              پشتیبانی ۲۴ ساعته، بهترین تجربه معاملاتی را برای شما فراهم کرده‌ایم.
            </p>

            <div className="flex flex-col items-center gap-3 sm:flex-row lg:items-start lg:justify-start">
              <a
                href="#trade"
                className="group flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-l from-[#F0B90B] to-[#F8D33A] px-8 py-4 text-base font-bold text-[#0B0E11] shadow-lg shadow-yellow-500/30 transition-all hover:shadow-yellow-500/50 sm:w-auto"
              >
                شروع معامله
                <svg className="h-5 w-5 transition-transform group-hover:-translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </a>
              <a
                href="#markets"
                className="flex w-full items-center justify-center gap-2 rounded-xl border border-[#2B3139] bg-[#1E2329]/50 px-8 py-4 text-base font-medium text-white backdrop-blur transition-all hover:border-[#F0B90B]/50 hover:bg-[#1E2329] sm:w-auto"
              >
                مشاهده بازارها
              </a>
            </div>

            {/* Trust Badges */}
            <div className="mt-10 flex items-center justify-center gap-6 text-xs text-[#848E9C] lg:justify-start">
              <div className="flex items-center gap-2">
                <svg className="h-5 w-5 text-[#F0B90B]" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M10 2L3 7v6c0 5 3 8 7 9 4-1 7-4 7-9V7l-7-5z"/>
                </svg>
                <span>امنیت بانکی</span>
              </div>
              <div className="flex items-center gap-2">
                <svg className="h-5 w-5 text-[#F0B90B]" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
                <span>مجوز رسمی</span>
              </div>
              <div className="flex items-center gap-2">
                <svg className="h-5 w-5 text-[#F0B90B]" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z"/>
                </svg>
                <span>+۵M کاربر</span>
              </div>
            </div>
          </div>

          {/* Right Content - Chart Card */}
          <div className="relative">
            <div className="absolute -inset-4 rounded-3xl bg-gradient-to-br from-[#F0B90B]/20 to-transparent blur-2xl"></div>
            <div className="relative rounded-2xl border border-[#2B3139] bg-gradient-to-br from-[#181A20] to-[#0B0E11] p-6 shadow-2xl shadow-black/50">
              {/* Card Header */}
              <div className="mb-6 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br from-[#F7931A] to-[#F7931A]/70 text-lg font-bold text-white shadow-lg shadow-orange-500/30">
                    ₿
                  </div>
                  <div>
                    <div className="text-base font-bold text-white">بیت کوین / تتر</div>
                    <div className="text-xs text-[#848E9C]">BTC/USDT</div>
                  </div>
                </div>
                <div className="rounded-lg bg-[#2EB589]/15 px-2.5 py-1 text-xs font-bold text-[#2EB589]">
                  +۲.۴۵٪
                </div>
              </div>

              {/* Price */}
              <div className="mb-6">
                <div className="text-3xl font-black text-white">
                  ۵,۸۴۲,۳۰۰,۰۰۰
                  <span className="mr-2 text-base font-normal text-[#848E9C]">تومان</span>
                </div>
                <div className="mt-1 text-sm text-[#2EB589]">
                  ▲ ۱۳۹,۴۰۰,۰۰۰ (۲.۴۵٪)
                </div>
              </div>

              {/* Mock Chart */}
              <div className="relative h-40 overflow-hidden rounded-xl bg-[#0B0E11]">
                <svg
                  viewBox="0 0 400 160"
                  className="h-full w-full"
                  preserveAspectRatio="none"
                >
                  <defs>
                    <linearGradient id="chartGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#2EB589" stopOpacity="0.4" />
                      <stop offset="100%" stopColor="#2EB589" stopOpacity="0" />
                    </linearGradient>
                  </defs>
                  <path
                    d="M0,120 L40,100 L80,110 L120,80 L160,90 L200,60 L240,70 L280,40 L320,55 L360,30 L400,20 L400,160 L0,160 Z"
                    fill="url(#chartGrad)"
                  />
                  <path
                    d="M0,120 L40,100 L80,110 L120,80 L160,90 L200,60 L240,70 L280,40 L320,55 L360,30 L400,20"
                    fill="none"
                    stroke="#2EB589"
                    strokeWidth="2.5"
                  />
                </svg>
                {/* Grid Lines */}
                <div className="pointer-events-none absolute inset-0 flex flex-col justify-between p-2">
                  {[0, 1, 2, 3].map((i) => (
                    <div key={i} className="h-px w-full bg-[#2B3139]/30"></div>
                  ))}
                </div>
              </div>

              {/* Timeframes */}
              <div className="mt-4 flex items-center justify-between text-xs">
                {["۱ساعت", "۲۴ساعت", "۱هفته", "۱ماه", "۱سال"].map((tf, i) => (
                  <button
                    key={tf}
                    className={`rounded-md px-3 py-1.5 transition-colors ${
                      i === 1
                        ? "bg-[#F0B90B]/15 text-[#F0B90B]"
                        : "text-[#848E9C] hover:text-white"
                    }`}
                  >
                    {tf}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
