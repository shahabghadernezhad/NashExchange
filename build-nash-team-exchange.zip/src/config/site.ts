// ============================================================
// 🌟 فایل تنظیمات اصلی سایت Nash Team
// هر چیزی که میخوای توی سایت عوض کنی، از اینجا شروع کن!
// ============================================================

export const siteConfig = {
  // اطلاعات کلی سایت
  brand: {
    name: "Nash Team",
    tagline: "صرافی ارز دیجیتال",
    description: "بزرگترین پلتفرم معاملاتی ارزهای دیجیتال در ایران",
    email: "support@nashteam.com",
    phone: "۰۲۱-۹۱۰۰۰۰۰۰",
    address: "تهران، خیابان میرداماد، پلاک ۱۲۳",
  },

  // لینک‌های شبکه‌های اجتماعی
  socials: {
    telegram: "https://t.me/nashteam",
    instagram: "https://instagram.com/nashteam",
    twitter: "https://twitter.com/nashteam",
    youtube: "https://youtube.com/@nashteam",
  },

  // منوی اصلی
  navLinks: [
    { label: "خرید و فروش", href: "#trade" },
    { label: "بازارها", href: "#markets" },
    { label: "ویژگی‌ها", href: "#features" },
    { label: "آکادمی", href: "#academy" },
    { label: "درباره ما", href: "#about" },
  ],

  // آمار و ارقام
  stats: [
    { value: "۵M+", label: "کاربر فعال" },
    { value: "$۲۴B", label: "حجم معاملات روزانه" },
    { value: "۳۵۰+", label: "ارز دیجیتال" },
    { value: "۲۴/۷", label: "پشتیبانی آنلاین" },
  ],

  // ویژگی‌های اصلی
  features: [
    {
      icon: "shield",
      title: "امنیت بالا",
      description: "دارایی شما با پیشرفته‌ترین تکنولوژی‌های امنیتی و کیف پول‌های سرد محافظت می‌شود.",
    },
    {
      icon: "zap",
      title: "سرعت بالا",
      description: "موتور معاملاتی پیشرفته ما توانایی پردازش ۱.۴ میلیون تراکنش در ثانیه را دارد.",
    },
    {
      icon: "trending",
      title: "کارمزد پایین",
      description: "با کارمزد ۰.۱٪ شروع کنید. هرچه بیشتر معامله کنید، کارمزد کمتری بپردازید.",
    },
    {
      icon: "globe",
      title: "دسترسی جهانی",
      description: "از هر نقطه جهان به بازارهای ارز دیجیتال دسترسی داشته باشید.",
    },
    {
      icon: "users",
      title: "جامعه بزرگ",
      description: "به بزرگترین جامعه تریدرهای ایرانی بپیوندید و از تجربیات آنها بیاموزید.",
    },
    {
      icon: "award",
      title: "پشتیبانی ۲۴/۷",
      description: "تیم پشتیبانی ما به صورت شبانه‌روزی آماده پاسخگویی به سوالات شما هستند.",
    },
  ],
};
