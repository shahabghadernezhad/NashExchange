// ============================================================
// 📊 داده‌های بازار ارزهای دیجیتال
// برای تغییر قیمت‌ها یا اضافه کردن ارز جدید، اینجا رو ویرایش کن
// ============================================================

export type Market = {
  rank: number;
  name: string;
  symbol: string;
  pair: string;
  icon: string;
  color: string;
  price: number; // قیمت به تومان
  change24h: number; // درصد تغییر ۲۴ ساعته
  volume24h: number; // حجم معاملات ۲۴ ساعته به تومان
  marketCap: number; // ارزش بازار
  high24h: number;
  low24h: number;
};

export const initialMarkets: Market[] = [
  {
    rank: 1,
    name: "بیت کوین",
    symbol: "BTC",
    pair: "BTC/USDT",
    icon: "₿",
    color: "#F7931A",
    price: 5_842_300_000,
    change24h: 2.45,
    volume24h: 1_250_000_000_000_000,
    marketCap: 115_000_000_000_000_000,
    high24h: 5_910_000_000,
    low24h: 5_720_000_000,
  },
  {
    rank: 2,
    name: "اتریوم",
    symbol: "ETH",
    pair: "ETH/USDT",
    icon: "Ξ",
    color: "#627EEA",
    price: 312_500_000,
    change24h: 3.82,
    volume24h: 780_000_000_000_000,
    marketCap: 37_500_000_000_000_000,
    high24h: 318_900_000,
    low24h: 301_200_000,
  },
  {
    rank: 3,
    name: "تتر",
    symbol: "USDT",
    pair: "USDT/IRT",
    icon: "₮",
    color: "#26A17B",
    price: 72_500,
    change24h: 0.05,
    volume24h: 4_500_000_000_000_000,
    marketCap: 118_000_000_000_000_000,
    high24h: 72_800,
    low24h: 72_300,
  },
  {
    rank: 4,
    name: "بایننس کوین",
    symbol: "BNB",
    pair: "BNB/USDT",
    icon: "B",
    color: "#F3BA2F",
    price: 58_200_000,
    change24h: -1.23,
    volume24h: 195_000_000_000_000,
    marketCap: 8_500_000_000_000_000,
    high24h: 59_100_000,
    low24h: 57_800_000,
  },
  {
    rank: 5,
    name: "ریپل",
    symbol: "XRP",
    pair: "XRP/USDT",
    icon: "X",
    color: "#23292F",
    price: 5_280,
    change24h: 5.67,
    volume24h: 145_000_000_000_000,
    marketCap: 2_900_000_000_000_000,
    high24h: 5_450,
    low24h: 4_980,
  },
  {
    rank: 6,
    name: "سولانا",
    symbol: "SOL",
    pair: "SOL/USDT",
    icon: "◎",
    color: "#14F195",
    price: 14_850_000,
    change24h: 4.21,
    volume24h: 98_000_000_000_000,
    marketCap: 6_800_000_000_000_000,
    high24h: 15_100_000,
    low24h: 14_200_000,
  },
  {
    rank: 7,
    name: "کاردانو",
    symbol: "ADA",
    pair: "ADA/USDT",
    icon: "₳",
    color: "#0033AD",
    price: 4_320,
    change24h: -2.15,
    volume24h: 45_000_000_000_000,
    marketCap: 1_500_000_000_000_000,
    high24h: 4_480,
    low24h: 4_280,
  },
  {
    rank: 8,
    name: "دوج کوین",
    symbol: "DOGE",
    pair: "DOGE/USDT",
    icon: "Ð",
    color: "#C2A633",
    price: 1_280,
    change24h: 8.92,
    volume24h: 78_000_000_000_000,
    marketCap: 1_850_000_000_000_000,
    high24h: 1_350,
    low24h: 1_180,
  },
];
