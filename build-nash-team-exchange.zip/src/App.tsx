import { useState } from "react";
import Header from "./components/Header";
import Hero from "./components/Hero";
import MarketTicker from "./components/MarketTicker";
import MarketTable from "./components/MarketTable";
import Features from "./components/Features";
import Stats from "./components/Stats";
import CTA from "./components/CTA";
import Footer from "./components/Footer";
import { initialMarkets } from "./data/markets";

export default function App() {
  const [markets] = useState(initialMarkets);

  return (
    <div
      className="min-h-screen bg-[#0B0E11] font-sans text-white"
      dir="rtl"
    >
      <Header />
      <main>
        <Hero />
        <MarketTicker markets={markets} />
        <MarketTable markets={markets} />
        <Stats />
        <Features />
        <CTA />
      </main>
      <Footer />
    </div>
  );
}
